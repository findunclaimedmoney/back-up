import { useState, useRef, useEffect, useCallback } from "react";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function genSession() { return "CS-" + Math.random().toString(36).substr(2,8).toUpperCase(); }
function fmtDate(d) {
  if (!d) return "—";
  return d.toLocaleString("en-AU", { weekday:"long", day:"2-digit", month:"long", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit", hour12:true });
}
function fmtDur(ms) {
  const s = Math.floor(ms/1000), h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
  return h>0 ? `${h}h ${m}m ${sec}s` : m>0 ? `${m}m ${sec}s` : `${sec}s`;
}

// QR via free API
function QRCode({ data, size=220 }) {
  const url = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(data)}&bgcolor=0a0a1e&color=7eb8ff&margin=12`;
  return <img src={url} alt="QR Code" style={{ width: size, height: size, borderRadius: 12 }} />;
}

// ─── Video Recorder ───────────────────────────────────────────────────────────
function VideoRecorder({ onRecorded, prompt }) {
  const vidRef = useRef(); const mrRef = useRef(); const chunksRef = useRef([]); const streamRef = useRef();
  const [phase, setPhase] = useState("idle");
  const [tick, setTick] = useState(0); const [cd, setCd] = useState(0);
  const [blobUrl, setBlobUrl] = useState(null); const [err, setErr] = useState(null);

  const openCam = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:"user" }, audio:true });
      streamRef.current = s;
      vidRef.current.srcObject = s; vidRef.current.muted = true; vidRef.current.play();
      setPhase("preview"); setErr(null);
    } catch { setErr("Camera/mic access denied. Please allow in browser settings."); }
  };

  const record = () => {
    let c=3; setCd(c);
    const iv = setInterval(()=>{ c--; setCd(c); if(c===0){ clearInterval(iv); go(); }},1000);
  };

  const go = () => {
    const mr = new MediaRecorder(streamRef.current, { mimeType:"video/webm" });
    mrRef.current = mr; chunksRef.current = [];
    mr.ondataavailable = e => chunksRef.current.push(e.data);
    mr.onstop = () => {
      const blob = new Blob(chunksRef.current, { type:"video/webm" });
      const url = URL.createObjectURL(blob);
      setBlobUrl(url); onRecorded(blob); setPhase("done");
      streamRef.current?.getTracks().forEach(t=>t.stop());
    };
    mr.start(); setPhase("rec");
    let t=0;
    const rt = setInterval(()=>{ t++; setTick(t); if(t>=60){ clearInterval(rt); mr.stop(); }},1000);
    mr._rt = rt;
  };

  const stop = () => { clearInterval(mrRef.current?._rt); mrRef.current?.stop(); };
  const retake = () => { setBlobUrl(null); setPhase("idle"); setTick(0); onRecorded(null); };
  useEffect(()=>()=>{ streamRef.current?.getTracks().forEach(t=>t.stop()); },[]);

  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
      {err && <div style={{ background:"#200", border:"1px solid #f44", borderRadius:8, padding:"10px 16px", color:"#f88", fontSize:13 }}>{err}</div>}
      <div style={{ width:"100%", maxWidth:360, aspectRatio:"4/3", background:"#030312", borderRadius:14, overflow:"hidden", position:"relative", border: phase==="rec" ? "2.5px solid #f44" : "2.5px solid #1a2a5e" }}>
        {phase==="done" ? <video src={blobUrl} controls style={{ width:"100%", height:"100%", objectFit:"cover" }}/> :
          <video ref={vidRef} autoPlay muted playsInline style={{ width:"100%", height:"100%", objectFit:"cover", transform:"scaleX(-1)" }}/>}
        {phase==="idle" && <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:8, color:"#445" }}>
          <div style={{ fontSize:38 }}>🎥</div><div style={{ fontSize:12 }}>Camera off</div></div>}
        {cd>0 && <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"#00000077" }}>
          <div style={{ fontSize:80, color:"#fff", fontWeight:900, fontFamily:"Georgia,serif" }}>{cd}</div></div>}
        {phase==="rec" && <div style={{ position:"absolute", top:10, left:10, display:"flex", alignItems:"center", gap:6 }}>
          <div style={{ width:9, height:9, borderRadius:"50%", background:"#f44", animation:"blink 1s infinite" }}/>
          <span style={{ color:"#fff", fontSize:12, fontWeight:700 }}>{tick}s / 60s</span></div>}
      </div>
      <div style={{ display:"flex", gap:8 }}>
        {phase==="idle" && <Btn onClick={openCam} color="#1a2a6e">📷 Open Camera</Btn>}
        {phase==="preview" && <Btn onClick={record} color="#1a5e2a">⏺ Record</Btn>}
        {phase==="rec" && <Btn onClick={stop} color="#5e1a1a">⏹ Stop</Btn>}
        {phase==="done" && <><Btn onClick={retake} color="#2a2a4a">🔄 Retake</Btn></>}
      </div>
      {phase==="done" && <div style={{ color:"#4caf50", fontSize:13, fontWeight:700 }}>✅ Video captured</div>}
      {prompt && <p style={{ color:"#556", fontSize:12, textAlign:"center", maxWidth:300, margin:0 }}>{prompt}</p>}
    </div>
  );
}

// ─── Reusable Bits ────────────────────────────────────────────────────────────
const Btn = ({onClick, color="#1a2a6e", disabled, children, full}) => (
  <button onClick={onClick} disabled={disabled} style={{
    background: disabled ? "#1a1a2a" : color, color: disabled ? "#444" : "#fff",
    border:"none", borderRadius:10, padding:"12px 22px", fontSize:14, fontWeight:700,
    cursor: disabled ? "not-allowed" : "pointer", fontFamily:"inherit", letterSpacing:0.4,
    width: full ? "100%" : undefined, transition:"opacity 0.2s", opacity: disabled ? 0.5 : 1
  }}>{children}</button>
);

const Input = ({value, onChange, placeholder, type="text"}) => (
  <input type={type} value={value} onChange={onChange} placeholder={placeholder} style={{
    width:"100%", background:"#0c0c20", border:"1.5px solid #1e1e3a", borderRadius:10,
    padding:"13px 16px", color:"#dde", fontSize:15, fontFamily:"inherit", boxSizing:"border-box",
    outline:"none"
  }}/>
);

const Label = ({children}) => <div style={{ fontSize:11, color:"#556", letterSpacing:3, textTransform:"uppercase", marginBottom:8 }}>{children}</div>;

function ProgressBar({ step, total }) {
  return (
    <div style={{ height:3, background:"#0f0f28", borderRadius:2, marginBottom:20 }}>
      <div style={{ height:"100%", background:"linear-gradient(90deg,#1a3aee,#4a8aff)", borderRadius:2, width:`${(step/total)*100}%`, transition:"width 0.4s ease" }}/>
    </div>
  );
}

function Tag({ color="#1a3aee", children }) {
  return <span style={{ background:color+"22", color:color, border:`1px solid ${color}44`, borderRadius:6, padding:"3px 10px", fontSize:11, fontWeight:700, letterSpacing:2, textTransform:"uppercase" }}>{children}</span>;
}

// ─── Certificate ──────────────────────────────────────────────────────────────
function Certificate({ s }) {
  const dur = s.endTime && s.startTime ? fmtDur(s.endTime - s.startTime) : "—";
  return (
    <div>
      <div id="cert-print" style={{ background:"#fff", border:"3px double #1a2a5e", borderRadius:12, padding:32, fontFamily:"'Georgia', serif", color:"#111", maxWidth:640, margin:"0 auto" }}>
        <div style={{ textAlign:"center", borderBottom:"2px solid #1a2a5e", paddingBottom:18, marginBottom:18 }}>
          <div style={{ fontSize:10, letterSpacing:5, color:"#999", marginBottom:4 }}>CONSENTSAFE™ LEGAL RECORD</div>
          <div style={{ fontSize:26, fontWeight:700, color:"#1a2a5e" }}>Mutual Consent Certificate</div>
          <div style={{ fontSize:12, color:"#666", marginTop:6 }}>Session ID: <strong style={{ color:"#1a2a5e", letterSpacing:2 }}>{s.sessionId}</strong></div>
        </div>

        <div style={{ background:"#f0f5ff", borderRadius:8, padding:"12px 16px", fontSize:11, color:"#444", marginBottom:18, lineHeight:1.7 }}>
          <strong>LEGAL NOTICE:</strong> This certificate records that both parties voluntarily and explicitly confirmed 
          mutual consent prior to a private intimate encounter, verified by: (1) timestamped video selfies with spoken 
          declarations, (2) GPS coordinates at time of consent, (3) facial capture, and (4) a signed closing confirmation 
          that no incident occurred. This document may be produced as supporting evidence in legal proceedings in Australian courts.
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:18 }}>
          {[
            { label:"Party A (Initiating)", name:s.manName, detail:"Consent session creator" },
            { label:"Party B (Consenting)", name:s.womanName, detail:"QR scan respondent" },
          ].map(p=>(
            <div key={p.label} style={{ border:"1px solid #dde", borderRadius:8, padding:14 }}>
              <div style={{ fontSize:10, letterSpacing:3, color:"#999", textTransform:"uppercase", marginBottom:3 }}>{p.label}</div>
              <div style={{ fontWeight:700, fontSize:15, color:"#1a2a5e" }}>{p.name}</div>
              <div style={{ fontSize:11, color:"#888" }}>{p.detail}</div>
            </div>
          ))}
        </div>

        {[
          ["Pre-Consent Timestamp", fmtDate(s.startTime)],
          ["GPS Location at Consent", s.gps || "Captured on device"],
          ["Encounter Concluded", fmtDate(s.endTime)],
          ["Total Duration Together", dur],
        ].map(([l,v])=>(
          <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid #f0f0f0", fontSize:13 }}>
            <span style={{ color:"#666" }}>{l}</span>
            <span style={{ fontWeight:700, color:"#1a2a5e", textAlign:"right", maxWidth:"55%" }}>{v}</span>
          </div>
        ))}

        <div style={{ background:"#f5fff8", border:"1px solid #c3e6cb", borderRadius:8, padding:"14px 16px", margin:"18px 0" }}>
          <div style={{ fontWeight:700, color:"#1a5e2a", marginBottom:10, fontSize:13 }}>✅ Both Parties Declare Under This Record:</div>
          {[
            "Consent was given freely, voluntarily, and without coercion or duress",
            "Both individuals confirmed they were of legal age and sound mind",
            "Party B confirmed consent on their own device via QR scan with GPS verification",
            "Both parties recorded video selfies with spoken consent declarations",
            "The encounter concluded and both confirmed no incident occurred",
            "Party B's facial image was captured at time of consent for identity verification",
          ].map((d,i)=>(
            <div key={i} style={{ fontSize:12, color:"#333", paddingLeft:16, marginBottom:5, position:"relative" }}>
              <span style={{ position:"absolute", left:0 }}>•</span>{d}
            </div>
          ))}
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
          {[s.manName, s.womanName].map((nm,i)=>(
            <div key={i} style={{ borderTop:"2px solid #1a2a5e", paddingTop:10, textAlign:"center" }}>
              <div style={{ fontSize:20, fontFamily:"cursive", color:"#1a2a5e", marginBottom:4 }}>{nm}</div>
              <div style={{ fontSize:10, color:"#888" }}>{i===0 ? "Party A — Initiated Session" : "Party B — QR Consent + Facial ID"}</div>
              <div style={{ fontSize:10, color:"#aaa", marginTop:3 }}>Video selfie + spoken declaration on file</div>
            </div>
          ))}
        </div>

        <div style={{ borderTop:"1px solid #dde", paddingTop:12, textAlign:"center", fontSize:10, color:"#bbb", marginTop:18 }}>
          Generated by ConsentSafe™ • {fmtDate(new Date())} • This record has been emailed to both parties • {s.sessionId}
        </div>
      </div>

      <div style={{ display:"flex", gap:10, justifyContent:"center", marginTop:18 }}>
        <Btn onClick={()=>window.print()} color="#1a2a5e">🖨️ Print / Save as PDF</Btn>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
const VIEW = { SETUP:"setup", QR:"qr", HER_SCAN:"her_scan", HER_VIDEO:"her_video", HER_DONE:"her_done", SESSION:"session", CLOSE_A:"closeA", CLOSE_B:"closeB", CERT:"cert" };

export default function ConsentApp() {
  const [view, setView] = useState(VIEW.SETUP);
  const [manName, setManName] = useState("");
  const [manEmail, setManEmail] = useState("");
  const [womanName, setWomanName] = useState("");
  const [womanEmail, setWomanEmail] = useState("");
  const [session, setSession] = useState({ sessionId:null, startTime:null, endTime:null, gps:null, manVideo:null, womanVideo:null, closeAVideo:null, closeBVideo:null, manName:"", womanName:"", manEmail:"", womanEmail:"" });
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef();
  const [gps, setGps] = useState(null);
  const [gpsStatus, setGpsStatus] = useState("idle");
  const [facePhoto, setFacePhoto] = useState(null);
  const photoRef = useRef(); const photoStreamRef = useRef();

  // Elapsed counter
  useEffect(()=>{
    if(view===VIEW.SESSION){ timerRef.current=setInterval(()=>setElapsed(e=>e+1),1000); }
    else clearInterval(timerRef.current);
    return ()=>clearInterval(timerRef.current);
  },[view]);

  // Get GPS
  const getGPS = () => {
    setGpsStatus("loading");
    navigator.geolocation?.getCurrentPosition(p=>{
      const coord = `${p.coords.latitude.toFixed(5)}, ${p.coords.longitude.toFixed(5)}`;
      setGps(coord); setGpsStatus("ok");
      setSession(s=>({...s, gps:coord}));
    }, ()=>{ setGps("Location unavailable"); setGpsStatus("error"); });
  };

  // Face photo
  const startFaceCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:"user" } });
      photoStreamRef.current = stream;
      photoRef.current.srcObject = stream; photoRef.current.muted = true; photoRef.current.play();
    } catch { alert("Camera access required for facial verification."); }
  };

  const snapPhoto = () => {
    const canvas = document.createElement("canvas");
    canvas.width = photoRef.current.videoWidth || 320;
    canvas.height = photoRef.current.videoHeight || 240;
    canvas.getContext("2d").drawImage(photoRef.current, 0, 0);
    setFacePhoto(canvas.toDataURL("image/jpeg"));
    photoStreamRef.current?.getTracks().forEach(t=>t.stop());
  };

  const generateQR = () => {
    const id = genSession();
    setSession({ sessionId:id, startTime:null, endTime:null, gps:null, manVideo:null, womanVideo:null, closeAVideo:null, closeBVideo:null, manName, womanName, manEmail, womanEmail });
    setView(VIEW.QR);
  };

  const lockConsent = () => {
    setSession(s=>({...s, startTime:new Date()}));
    setElapsed(0); setView(VIEW.SESSION);
  };

  const finalise = () => {
    setSession(s=>({...s, endTime:new Date()}));
    setView(VIEW.CERT);
  };

  // QR encodes the session data
  const qrData = session.sessionId
    ? `ConsentSafe Session ${session.sessionId} | Consent requested by: ${manName} | Date: ${new Date().toLocaleDateString("en-AU")} | Scan to confirm your consent`
    : "";

  // ─── Her consent page (simulates what she sees after scanning QR on her phone)
  const HerConsentPage = () => (
    <div style={{ background:"#f8f9ff", borderRadius:16, padding:20, maxWidth:380, margin:"0 auto", fontFamily:"'Georgia',serif", border:"2px solid #c0d0ff" }}>
      <div style={{ textAlign:"center", marginBottom:18 }}>
        <div style={{ fontSize:28 }}>🤝</div>
        <div style={{ fontSize:18, fontWeight:700, color:"#1a2a5e", margin:"6px 0 4px" }}>Consent Confirmation</div>
        <div style={{ fontSize:12, color:"#888" }}>ConsentSafe™ — Secure Mutual Consent</div>
      </div>

      <div style={{ background:"#e8f0ff", borderRadius:10, padding:"12px 14px", marginBottom:16, fontSize:13, color:"#2a3a7e", lineHeight:1.6 }}>
        <strong>{manName}</strong> has requested your mutual consent confirmation for a private encounter.<br/>
        <span style={{ fontSize:11, color:"#667" }}>Date: {new Date().toLocaleDateString("en-AU")} • Session: {session.sessionId}</span>
      </div>

      {/* GPS */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#667", letterSpacing:2, textTransform:"uppercase", marginBottom:6 }}>📍 Location Verification</div>
        {gpsStatus==="idle" && <button onClick={getGPS} style={{ background:"#1a3a8e", color:"#fff", border:"none", borderRadius:8, padding:"10px 18px", fontSize:13, cursor:"pointer", fontFamily:"inherit" }}>Capture My GPS Location</button>}
        {gpsStatus==="loading" && <div style={{ color:"#667", fontSize:13 }}>Getting location…</div>}
        {gpsStatus==="ok" && <div style={{ background:"#e8ffe8", borderRadius:8, padding:"8px 12px", fontSize:12, color:"#1a5e2a" }}>✅ GPS: {gps}</div>}
        {gpsStatus==="error" && <div style={{ color:"#c44", fontSize:12 }}>Location unavailable — please enable location access</div>}
      </div>

      {/* Face photo */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#667", letterSpacing:2, textTransform:"uppercase", marginBottom:6 }}>🤳 Facial Verification</div>
        {!facePhoto ? (
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <div style={{ width:"100%", aspectRatio:"4/3", background:"#0a0a14", borderRadius:10, overflow:"hidden" }}>
              <video ref={photoRef} autoPlay muted playsInline style={{ width:"100%", height:"100%", objectFit:"cover", transform:"scaleX(-1)" }}/>
            </div>
            <div style={{ display:"flex", gap:8 }}>
              <button onClick={startFaceCapture} style={{ flex:1, background:"#2a2a5e", color:"#fff", border:"none", borderRadius:8, padding:"10px", fontSize:13, cursor:"pointer" }}>📷 Open Camera</button>
              <button onClick={snapPhoto} style={{ flex:1, background:"#1a5e2a", color:"#fff", border:"none", borderRadius:8, padding:"10px", fontSize:13, cursor:"pointer" }}>📸 Capture</button>
            </div>
          </div>
        ) : (
          <div>
            <img src={facePhoto} alt="Face" style={{ width:"100%", borderRadius:10, border:"2px solid #4caf50" }}/>
            <div style={{ color:"#1a5e2a", fontSize:12, fontWeight:700, marginTop:6 }}>✅ Face captured</div>
            <button onClick={()=>setFacePhoto(null)} style={{ fontSize:11, color:"#888", background:"none", border:"none", cursor:"pointer", marginTop:4 }}>Retake</button>
          </div>
        )}
      </div>

      {/* Her name */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#667", letterSpacing:2, textTransform:"uppercase", marginBottom:6 }}>Your Full Name</div>
        <input value={womanName} onChange={e=>setWomanName(e.target.value)} placeholder="Enter your full name"
          style={{ width:"100%", border:"1.5px solid #ccd", borderRadius:8, padding:"11px 14px", fontSize:14, fontFamily:"inherit", boxSizing:"border-box" }}/>
      </div>
      <div style={{ marginBottom:16 }}>
        <div style={{ fontSize:11, color:"#667", letterSpacing:2, textTransform:"uppercase", marginBottom:6 }}>Your Email (for certificate)</div>
        <input type="email" value={womanEmail} onChange={e=>setWomanEmail(e.target.value)} placeholder="your@email.com"
          style={{ width:"100%", border:"1.5px solid #ccd", borderRadius:8, padding:"11px 14px", fontSize:14, fontFamily:"inherit", boxSizing:"border-box" }}/>
      </div>

      <div style={{ background:"#fff8e8", border:"1px solid #e8c860", borderRadius:10, padding:"12px 14px", marginBottom:16, fontSize:12, color:"#664", lineHeight:1.7 }}>
        <strong>By proceeding you confirm:</strong><br/>
        You are voluntarily consenting to an intimate encounter with <strong>{manName}</strong>, 
        you are of legal age and sound mind, and you are not under any duress or coercion.
      </div>

      <button
        disabled={!womanName || !womanEmail || gpsStatus!=="ok" || !facePhoto}
        onClick={()=>setView(VIEW.HER_VIDEO)}
        style={{ width:"100%", background: (womanName&&womanEmail&&gpsStatus==="ok"&&facePhoto)?"#1a5e2a":"#ccc", color:"#fff", border:"none", borderRadius:10, padding:"14px", fontSize:15, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
        🎥 Record My Video Consent →
      </button>
      <div style={{ fontSize:11, color:"#aaa", textAlign:"center", marginTop:8 }}>All fields required before recording</div>
    </div>
  );

  // ─── Consent script for her video
  const herScript = `"My name is ${womanName || "[your name]"}. Today is ${new Date().toLocaleDateString("en-AU", {weekday:"long", day:"numeric", month:"long", year:"numeric"})}. I am giving my free, voluntary, and enthusiastic consent to an intimate encounter with ${manName || "[his name]"}. I am of sound mind, I am not under duress, I am of legal age, and I understand that I may withdraw consent at any time. I confirm my GPS location and this video is taken on today's date."`;

  // ─── Closing scripts
  const closeScript = (myName, otherName) =>
    `"My name is ${myName}. I am closing the ConsentSafe session ${session.sessionId} with ${otherName}. The encounter between us has now concluded. I confirm it was fully consensual throughout, no incident occurred, and I am in good health and of sound mind at this time."`;

  // ──────────────────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight:"100vh", background:"#07071a", fontFamily:"'Trebuchet MS','Lucida Grande',sans-serif", color:"#dde" }}>
      <style>{`
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        .fade{animation:fadeUp 0.4s ease forwards}
        @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.03)}}
        @media print { body>*{display:none!important} #cert-print{display:block!important} }
      `}</style>

      {/* Header */}
      <div style={{ background:"#080820", borderBottom:"1px solid #151538", padding:"14px 24px", display:"flex", alignItems:"center", gap:14 }}>
        <div style={{ width:38, height:38, background:"linear-gradient(135deg,#1a3aee,#3a6aff)", borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>🛡️</div>
        <div>
          <div style={{ fontWeight:800, fontSize:18, letterSpacing:1, color:"#c8d8ff" }}>ConsentSafe</div>
          <div style={{ fontSize:10, color:"#445", letterSpacing:3 }}>MUTUAL CONSENT RECORDER • AUSTRALIA</div>
        </div>
        {session.sessionId && <div style={{ marginLeft:"auto", fontSize:11, color:"#557", background:"#0f0f28", padding:"5px 12px", borderRadius:6 }}>
          <span style={{ color:"#7ab" }}>{session.sessionId}</span>
        </div>}
      </div>

      <div style={{ maxWidth:600, margin:"0 auto", padding:"28px 18px" }}>

        {/* ── SETUP ── */}
        {view===VIEW.SETUP && (
          <div className="fade">
            <div style={{ textAlign:"center", marginBottom:32 }}>
              <div style={{ fontSize:52, marginBottom:12 }}>🤝</div>
              <h1 style={{ fontSize:28, fontWeight:800, color:"#c8d8ff", margin:"0 0 10px" }}>ConsentSafe QR System</h1>
              <p style={{ color:"#667", lineHeight:1.8, maxWidth:460, margin:"0 auto 24px" }}>
                Generate a QR code she scans on her own phone. She confirms GPS location, facial ID, and records a spoken video consent — all on her own device.
              </p>
              <div style={{ display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap" }}>
                <Tag>📍 GPS Verified</Tag>
                <Tag color="#1a8e4a">🤳 Facial ID</Tag>
                <Tag color="#8e4a1a">🎥 Video Spoken</Tag>
                <Tag color="#4a1a8e">📜 Legal Certificate</Tag>
              </div>
            </div>

            <div style={{ background:"#0d0d28", borderRadius:14, padding:24, marginBottom:24 }}>
              <div style={{ fontSize:11, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:18 }}>Your Details (Party A)</div>
              <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
                <div><Label>Your Full Legal Name</Label><Input value={manName} onChange={e=>setManName(e.target.value)} placeholder="Enter your full name"/></div>
                <div><Label>Your Email</Label><Input type="email" value={manEmail} onChange={e=>setManEmail(e.target.value)} placeholder="your@email.com"/></div>
              </div>
            </div>

            <div style={{ background:"#0a1406", border:"1px solid #1e3a1e", borderRadius:10, padding:"14px 16px", marginBottom:24, fontSize:12, color:"#7a9a7a", lineHeight:1.7 }}>
              ⚖️ <strong>Legal Note (Australia):</strong> All states now operate under affirmative consent laws — consent must be actively given. This app creates a timestamped record that may support your case but does not guarantee any legal outcome. Consent can be withdrawn at any time. Consult a solicitor for case-specific advice.
            </div>

            <Btn full onClick={generateQR} disabled={!manName||!manEmail} color="#1a3aee">
              📱 Generate QR Code →
            </Btn>
          </div>
        )}

        {/* ── QR SCREEN ── */}
        {view===VIEW.QR && (
          <div className="fade" style={{ textAlign:"center" }}>
            <ProgressBar step={1} total={5}/>
            <div style={{ fontSize:11, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 1 of 5</div>
            <h2 style={{ fontSize:22, fontWeight:800, color:"#c8d8ff", marginBottom:6 }}>Show Her This QR Code</h2>
            <p style={{ color:"#667", fontSize:14, marginBottom:24 }}>
              Hand her your phone or show this QR code. She scans it on her own phone to open the consent form — prefilled with your name and the date.
            </p>

            <div style={{ background:"#0d0d28", borderRadius:18, padding:28, display:"inline-block", marginBottom:24, border:"1px solid #1a2a5e" }}>
              <QRCode data={qrData} size={230}/>
              <div style={{ marginTop:14, fontSize:11, color:"#445", letterSpacing:2 }}>SCAN ON HER PHONE</div>
              <div style={{ fontSize:12, color:"#7ab", marginTop:4, fontWeight:700 }}>{session.sessionId}</div>
            </div>

            <div style={{ background:"#0d0d28", borderRadius:12, padding:18, marginBottom:24, textAlign:"left" }}>
              <div style={{ fontSize:11, color:"#556", letterSpacing:3, textTransform:"uppercase", marginBottom:12 }}>What she will see on her phone:</div>
              {["Her name & email form (prefilled with your name)", "GPS location capture button", "Facial photo verification", "Video consent recording with spoken script"].map((t,i)=>(
                <div key={i} style={{ display:"flex", gap:10, marginBottom:8, fontSize:13, color:"#99a" }}>
                  <span style={{ color:"#4a7aee", minWidth:20 }}>{i+1}.</span>{t}
                </div>
              ))}
            </div>

            <div style={{ display:"flex", gap:10, justifyContent:"center", flexWrap:"wrap" }}>
              <Btn onClick={()=>setView(VIEW.HER_SCAN)} color="#1a5e2a">👇 Simulate Her Scan (Demo)</Btn>
              <Btn onClick={()=>setView(VIEW.SETUP)} color="#2a2a4a">← Back</Btn>
            </div>
            <div style={{ fontSize:11, color:"#445", marginTop:12 }}>In production, the QR links to a hosted URL she opens on her own device</div>
          </div>
        )}

        {/* ── HER SCAN PAGE ── */}
        {view===VIEW.HER_SCAN && (
          <div className="fade">
            <ProgressBar step={2} total={5}/>
            <div style={{ fontSize:11, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 2 of 5 — Her Device</div>
            <h2 style={{ fontSize:20, fontWeight:800, color:"#c8d8ff", marginBottom:6 }}>Her Phone — Consent Form</h2>
            <p style={{ color:"#667", fontSize:13, marginBottom:20 }}>This is what appears on her phone after scanning. She fills this in herself.</p>
            <HerConsentPage/>
          </div>
        )}

        {/* ── HER VIDEO ── */}
        {view===VIEW.HER_VIDEO && (
          <div className="fade">
            <ProgressBar step={3} total={5}/>
            <div style={{ fontSize:11, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 3 of 5 — Her Device</div>
            <h2 style={{ fontSize:20, fontWeight:800, color:"#c8d8ff", marginBottom:16 }}>{womanName} — Record Consent Video</h2>
            <div style={{ background:"#0d1e0d", border:"1px solid #2a4a2a", borderRadius:10, padding:16, marginBottom:20 }}>
              <div style={{ fontSize:10, color:"#4a8a4a", letterSpacing:3, textTransform:"uppercase", marginBottom:10 }}>📣 Read This On Camera:</div>
              <div style={{ fontSize:14, color:"#cce", lineHeight:1.9, fontStyle:"italic" }}>{herScript}</div>
            </div>
            <VideoRecorder
              prompt="Record yourself reading the full statement above clearly and calmly. Max 60 seconds."
              onRecorded={blob=>setSession(s=>({...s, womanVideo:blob}))}
            />
            <div style={{ marginTop:20 }}>
              <Btn full disabled={!session.womanVideo} onClick={()=>setView(VIEW.HER_DONE)} color="#1a5e2a">✅ Submit Consent →</Btn>
            </div>
          </div>
        )}

        {/* ── HER DONE ── */}
        {view===VIEW.HER_DONE && (
          <div className="fade" style={{ textAlign:"center" }}>
            <ProgressBar step={3} total={5}/>
            <div style={{ fontSize:52, marginBottom:12 }}>✅</div>
            <h2 style={{ color:"#4caf50", fontSize:22, marginBottom:8 }}>Consent Confirmed by {womanName}</h2>
            <p style={{ color:"#778", fontSize:14, marginBottom:24 }}>
              GPS location, facial photo, and video consent recorded. Session now locked.
            </p>
            <div style={{ background:"#0d0d28", borderRadius:12, padding:18, marginBottom:24 }}>
              {[["Party A",manName],["Party B",womanName],["GPS",gps||"Captured"],["Session",session.sessionId]].map(([l,v])=>(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid #0f0f28", fontSize:13 }}>
                  <span style={{ color:"#556" }}>{l}</span><span style={{ color:"#aab", fontWeight:700 }}>{v}</span>
                </div>
              ))}
            </div>
            <Btn full onClick={lockConsent} color="#1a3aee">🔒 Lock Session & Start Timer →</Btn>
          </div>
        )}

        {/* ── SESSION ACTIVE ── */}
        {view===VIEW.SESSION && (
          <div className="fade" style={{ textAlign:"center" }}>
            <ProgressBar step={4} total={5}/>
            <div style={{ fontSize:44, marginBottom:10, animation:"pulse 2s infinite" }}>🔒</div>
            <h2 style={{ color:"#4caf50", fontSize:20, marginBottom:6 }}>Session Active</h2>
            <div style={{ color:"#667", fontSize:13, marginBottom:20 }}>Both parties have confirmed mutual consent. Timer running.</div>

            <div style={{ background:"#0d0d28", borderRadius:14, padding:22, marginBottom:20 }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:16 }}>
                {[["Party A",manName],["Party B",womanName]].map(([l,v])=>(
                  <div key={l} style={{ background:"#0a0a1e", borderRadius:8, padding:"10px 12px" }}>
                    <div style={{ fontSize:10, color:"#445", letterSpacing:2, textTransform:"uppercase", marginBottom:3 }}>{l}</div>
                    <div style={{ fontSize:13, fontWeight:700, color:"#aab" }}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{ borderTop:"1px solid #1a1a3a", paddingTop:14 }}>
                <div style={{ fontSize:10, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:4 }}>Session ID</div>
                <div style={{ fontSize:16, fontWeight:700, color:"#7ab", letterSpacing:3 }}>{session.sessionId}</div>
              </div>
              <div style={{ marginTop:14, background:"#0a120a", borderRadius:8, padding:"12px" }}>
                <div style={{ fontSize:10, color:"#4a8a4a", letterSpacing:3, textTransform:"uppercase", marginBottom:3 }}>Time Together</div>
                <div style={{ fontSize:36, fontWeight:800, color:"#4caf50", fontFamily:"monospace" }}>{fmtDur(elapsed*1000)}</div>
              </div>
            </div>

            <Btn full onClick={()=>setView(VIEW.CLOSE_A)} color="#3a1a8e">🏁 Encounter Concluded — Record Closing Statements</Btn>
          </div>
        )}

        {/* ── CLOSE A ── */}
        {view===VIEW.CLOSE_A && (
          <div className="fade">
            <ProgressBar step={5} total={5}/>
            <div style={{ fontSize:11, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Closing — Party A</div>
            <h2 style={{ fontSize:20, fontWeight:800, color:"#c8d8ff", marginBottom:16 }}>{manName} — Closing Confirmation</h2>
            <div style={{ background:"#0d0d28", border:"1px solid #1a2a5e", borderRadius:10, padding:16, marginBottom:20 }}>
              <div style={{ fontSize:10, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:10 }}>📣 Read On Camera:</div>
              <div style={{ fontSize:14, color:"#cce", lineHeight:1.9, fontStyle:"italic" }}>{closeScript(manName, womanName)}</div>
            </div>
            <VideoRecorder prompt="Record your closing confirmation." onRecorded={blob=>setSession(s=>({...s, closeAVideo:blob}))}/>
            <div style={{ marginTop:20 }}>
              <Btn full disabled={!session.closeAVideo} onClick={()=>setView(VIEW.CLOSE_B)} color="#1a3aee">✅ Done — Party B's Turn →</Btn>
            </div>
          </div>
        )}

        {/* ── CLOSE B ── */}
        {view===VIEW.CLOSE_B && (
          <div className="fade">
            <ProgressBar step={5} total={5}/>
            <div style={{ fontSize:11, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Closing — Party B</div>
            <h2 style={{ fontSize:20, fontWeight:800, color:"#c8d8ff", marginBottom:16 }}>{womanName} — Closing Confirmation</h2>
            <div style={{ background:"#0d0d28", border:"1px solid #1a2a5e", borderRadius:10, padding:16, marginBottom:20 }}>
              <div style={{ fontSize:10, color:"#4a7aee", letterSpacing:3, textTransform:"uppercase", marginBottom:10 }}>📣 Read On Camera:</div>
              <div style={{ fontSize:14, color:"#cce", lineHeight:1.9, fontStyle:"italic" }}>{closeScript(womanName, manName)}</div>
            </div>
            <VideoRecorder prompt="Record your closing confirmation." onRecorded={blob=>setSession(s=>({...s, closeBVideo:blob}))}/>
            <div style={{ marginTop:20 }}>
              <Btn full disabled={!session.closeBVideo} onClick={finalise} color="#1a6e3a">📜 Generate Certificate →</Btn>
            </div>
          </div>
        )}

        {/* ── CERTIFICATE ── */}
        {view===VIEW.CERT && (
          <div className="fade">
            <div style={{ textAlign:"center", marginBottom:24 }}>
              <div style={{ fontSize:48, marginBottom:8 }}>📜</div>
              <h2 style={{ color:"#4caf50", fontSize:22, marginBottom:6 }}>Legal Certificate Generated</h2>
              <p style={{ color:"#778", fontSize:13 }}>Emailed to {manEmail} and {womanEmail}.<br/>Print or save as PDF below.</p>
            </div>
            <Certificate s={session}/>
            <div style={{ textAlign:"center", marginTop:20 }}>
              <Btn onClick={()=>{ setView(VIEW.SETUP); setSession({sessionId:null,startTime:null,endTime:null,gps:null,manVideo:null,womanVideo:null,closeAVideo:null,closeBVideo:null,manName:"",womanName:"",manEmail:"",womanEmail:""}); setGps(null); setGpsStatus("idle"); setFacePhoto(null); setManName(""); setManEmail(""); setWomanName(""); setWomanEmail(""); }} color="#2a2a4a">
                ← Start New Session
              </Btn>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

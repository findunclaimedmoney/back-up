import { useState, useRef, useEffect, useCallback } from "react";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmtDate = (d) => d ? new Date(d).toLocaleDateString("en-AU", { day:"2-digit", month:"long", year:"numeric" }) : "";
const nowStr  = () => new Date().toLocaleString("en-AU", { weekday:"long", day:"2-digit", month:"long", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit", hour12:true });

const NAVY="#0d1e4a", GOLD="#c9a84c", GREEN="#1a5e2a";

// ─── Styles ───────────────────────────────────────────────────────────────────
const inp = {
  width:"100%", background:"#0a0f1e", border:"1.5px solid #1a2a4a",
  borderRadius:10, padding:"13px 16px", color:"#dde", fontSize:14,
  fontFamily:"inherit", boxSizing:"border-box", outline:"none"
};
const Btn = ({ onClick, color=GOLD, textColor="#07080f", disabled, children, full, size="md" }) => (
  <button onClick={onClick} disabled={disabled} style={{
    background:disabled?"#1a2a4a":color, color:disabled?"#445":textColor,
    border:"none", borderRadius:10, cursor:disabled?"not-allowed":"pointer",
    padding:size==="lg"?"16px 32px":size==="sm"?"8px 16px":"12px 22px",
    fontSize:size==="lg"?15:size==="sm"?12:14, fontWeight:800,
    fontFamily:"inherit", width:full?"100%":undefined,
    opacity:disabled?0.5:1, transition:"all 0.2s", letterSpacing:0.5
  }}>{children}</button>
);
const Lbl = ({children}) => <div style={{fontSize:11,color:"#445",letterSpacing:2.5,textTransform:"uppercase",marginBottom:7,fontWeight:700}}>{children}</div>;

// ─── Step Indicator ───────────────────────────────────────────────────────────
const STEPS = ["Details","Face Verify","Licence Upload","Declaration","Signature","Certificate"];
function StepBar({ current }) {
  return (
    <div style={{ display:"flex", gap:0, marginBottom:32 }}>
      {STEPS.map((s,i)=>{
        const done = i < current, active = i === current;
        return (
          <div key={s} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center" }}>
            <div style={{ display:"flex", alignItems:"center", width:"100%" }}>
              {i>0 && <div style={{ flex:1, height:2, background: done?"#c9a84c":"#1a2a4a" }}/>}
              <div style={{ width:32, height:32, borderRadius:"50%", background: done?"#c9a84c":active?"#1a2a5e":"#0d1020", border:`2px solid ${done||active?"#c9a84c":"#1a2a4a"}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight:800, color: done?"#07080f":active?"#c9a84c":"#334", zIndex:1 }}>
                {done ? "✓" : i+1}
              </div>
              {i<STEPS.length-1 && <div style={{ flex:1, height:2, background: done?"#c9a84c":"#1a2a4a" }}/>}
            </div>
            <div style={{ fontSize:9, color: active?"#c9a84c":done?"#8a7a3a":"#334", marginTop:5, letterSpacing:1, textTransform:"uppercase", textAlign:"center" }}>{s}</div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Signature Pad ────────────────────────────────────────────────────────────
function SigPad({ onSign }) {
  const canvasRef = useRef();
  const drawing = useRef(false);
  const [signed, setSigned] = useState(false);

  const getPos = (e, canvas) => {
    const r = canvas.getBoundingClientRect();
    const src = e.touches ? e.touches[0] : e;
    return [src.clientX - r.left, src.clientY - r.top];
  };

  const start = (e) => {
    e.preventDefault();
    drawing.current = true;
    const ctx = canvasRef.current.getContext("2d");
    const [x,y] = getPos(e, canvasRef.current);
    ctx.beginPath(); ctx.moveTo(x,y);
  };

  const draw = (e) => {
    if (!drawing.current) return;
    e.preventDefault();
    const ctx = canvasRef.current.getContext("2d");
    const [x,y] = getPos(e, canvasRef.current);
    ctx.lineTo(x,y);
    ctx.strokeStyle="#c9a84c"; ctx.lineWidth=2.5; ctx.lineCap="round";
    ctx.stroke();
    setSigned(true);
  };

  const stop = () => {
    drawing.current = false;
    if (signed) onSign(canvasRef.current.toDataURL());
  };

  const clear = () => {
    const ctx = canvasRef.current.getContext("2d");
    ctx.clearRect(0,0,canvasRef.current.width,canvasRef.current.height);
    setSigned(false); onSign(null);
  };

  return (
    <div>
      <div style={{ border:"2px solid #1a2a4a", borderRadius:12, overflow:"hidden", background:"#030408", position:"relative" }}>
        <canvas ref={canvasRef} width={520} height={140}
          style={{ display:"block", width:"100%", height:140, touchAction:"none", cursor:"crosshair" }}
          onMouseDown={start} onMouseMove={draw} onMouseUp={stop} onMouseLeave={stop}
          onTouchStart={start} onTouchMove={draw} onTouchEnd={stop}/>
        {!signed && <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", pointerEvents:"none" }}>
          <span style={{ color:"#1a2a4a", fontSize:13 }}>✍️ Draw your signature here</span>
        </div>}
      </div>
      <button onClick={clear} style={{ background:"none", border:"none", color:"#556", fontSize:12, cursor:"pointer", marginTop:6, fontFamily:"inherit" }}>🗑 Clear</button>
      {signed && <div style={{ color:"#4caf50", fontSize:12, marginTop:4 }}>✅ Signature captured</div>}
    </div>
  );
}

// ─── Face Capture ─────────────────────────────────────────────────────────────
function FaceCapture({ onCapture }) {
  const vidRef = useRef(); const streamRef = useRef();
  const [phase, setPhase] = useState("idle");
  const [photo, setPhoto] = useState(null);
  const [err, setErr]     = useState(null);

  const open = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:"user" }, audio:false });
      streamRef.current = s;
      vidRef.current.srcObject = s; vidRef.current.play();
      setPhase("preview"); setErr(null);
    } catch { setErr("Camera access denied — please allow camera in browser settings."); }
  };

  const snap = () => {
    const c = document.createElement("canvas");
    c.width = vidRef.current.videoWidth || 320;
    c.height = vidRef.current.videoHeight || 240;
    c.getContext("2d").drawImage(vidRef.current,0,0);
    const url = c.toDataURL("image/jpeg",0.92);
    setPhoto(url); onCapture(url);
    streamRef.current?.getTracks().forEach(t=>t.stop());
    setPhase("done");
  };

  const retake = () => { setPhoto(null); onCapture(null); setPhase("idle"); };
  useEffect(()=>()=>{ streamRef.current?.getTracks().forEach(t=>t.stop()); },[]);

  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
      {err && <div style={{ background:"#200", border:"1px solid #f44", borderRadius:8, padding:"10px 14px", color:"#f88", fontSize:13 }}>{err}</div>}
      <div style={{ width:"100%", maxWidth:340, aspectRatio:"4/3", background:"#030408", borderRadius:14, overflow:"hidden", border:"2px solid #1a2a4a", position:"relative" }}>
        {phase==="done" ? <img src={photo} style={{ width:"100%", height:"100%", objectFit:"cover" }} alt="face"/>
          : <video ref={vidRef} autoPlay muted playsInline style={{ width:"100%", height:"100%", objectFit:"cover", transform:"scaleX(-1)" }}/>}
        {phase==="idle" && <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", color:"#334", gap:8 }}>
          <div style={{ fontSize:36 }}>🤳</div><div style={{ fontSize:12 }}>Camera off</div></div>}
        {phase==="preview" && (
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", pointerEvents:"none" }}>
            <div style={{ width:160, height:200, border:"2px dashed #c9a84c66", borderRadius:"50%", boxShadow:"inset 0 0 0 1px #c9a84c22" }}/>
          </div>
        )}
      </div>
      <div style={{ display:"flex", gap:8 }}>
        {phase==="idle" && <Btn onClick={open} color="#1a2a5e" textColor="#c8d8ff">📷 Open Camera</Btn>}
        {phase==="preview" && <Btn onClick={snap} color={GREEN} textColor="#fff">📸 Capture Photo</Btn>}
        {phase==="done" && <Btn onClick={retake} color="#2a2a4a" textColor="#c8d8ff">🔄 Retake</Btn>}
      </div>
      {phase==="done" && <div style={{ color:"#4caf50", fontSize:13, fontWeight:700 }}>✅ Face captured successfully</div>}
      <p style={{ color:"#445", fontSize:11, textAlign:"center", maxWidth:300, margin:0, lineHeight:1.6 }}>
        Position your face clearly in the oval guide. This photo is stored securely with your petition record for identity verification purposes.
      </p>
    </div>
  );
}

// ─── Licence Upload ───────────────────────────────────────────────────────────
function LicenceUpload({ onUpload }) {
  const [preview, setPreview] = useState(null);
  const [method, setMethod]   = useState(null);
  const fileRef = useRef(); const vidRef = useRef(); const streamRef = useRef();
  const [camOpen, setCamOpen] = useState(false);

  const handleFile = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = (ev) => { setPreview(ev.target.result); onUpload(ev.target.result); setMethod("upload"); };
    r.readAsDataURL(f);
  };

  const openCam = async () => {
    setCamOpen(true); setMethod("camera");
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:"environment" }, audio:false });
      streamRef.current = s;
      setTimeout(() => { if(vidRef.current) { vidRef.current.srcObject=s; vidRef.current.play(); }},100);
    } catch {
      try {
        const s = await navigator.mediaDevices.getUserMedia({ video:true, audio:false });
        streamRef.current = s;
        setTimeout(() => { if(vidRef.current) { vidRef.current.srcObject=s; vidRef.current.play(); }},100);
      } catch { setCamOpen(false); }
    }
  };

  const snapLicence = () => {
    const c = document.createElement("canvas");
    c.width = vidRef.current.videoWidth||640; c.height = vidRef.current.videoHeight||480;
    c.getContext("2d").drawImage(vidRef.current,0,0);
    const url = c.toDataURL("image/jpeg",0.92);
    setPreview(url); onUpload(url);
    streamRef.current?.getTracks().forEach(t=>t.stop());
    setCamOpen(false);
  };

  const reset = () => { setPreview(null); onUpload(null); setMethod(null); setCamOpen(false); streamRef.current?.getTracks().forEach(t=>t.stop()); };
  useEffect(()=>()=>{ streamRef.current?.getTracks().forEach(t=>t.stop()); },[]);

  if (preview) return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
      <div style={{ background:"#0d1628", border:"2px solid #4caf50", borderRadius:12, overflow:"hidden", maxWidth:380, width:"100%" }}>
        <img src={preview} style={{ width:"100%", objectFit:"contain", maxHeight:220 }} alt="licence"/>
      </div>
      <div style={{ color:"#4caf50", fontSize:13, fontWeight:700 }}>✅ Licence/Passport captured</div>
      <Btn onClick={reset} color="#2a2a4a" textColor="#c8d8ff" size="sm">🔄 Replace</Btn>
    </div>
  );

  if (camOpen) return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
      <div style={{ background:"#030408", border:"2px solid #1a2a4a", borderRadius:12, overflow:"hidden", width:"100%", maxWidth:380 }}>
        <video ref={vidRef} autoPlay muted playsInline style={{ width:"100%", display:"block" }}/>
      </div>
      <div style={{ display:"flex", gap:8 }}>
        <Btn onClick={snapLicence} color={GREEN} textColor="#fff">📸 Capture Licence</Btn>
        <Btn onClick={reset} color="#2a2a4a" textColor="#c8d8ff">Cancel</Btn>
      </div>
      <p style={{ color:"#445", fontSize:11, textAlign:"center" }}>Lay your licence flat and capture clearly — all 4 corners visible</p>
    </div>
  );

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <div onClick={()=>fileRef.current.click()} style={{ background:"#0a0f1e", border:"2px dashed #1a2a4a", borderRadius:12, padding:24, textAlign:"center", cursor:"pointer" }}>
          <div style={{ fontSize:32, marginBottom:8 }}>📁</div>
          <div style={{ fontWeight:700, color:"#8ab", fontSize:13 }}>Upload File</div>
          <div style={{ color:"#445", fontSize:11, marginTop:4 }}>JPG, PNG or PDF</div>
        </div>
        <div onClick={openCam} style={{ background:"#0a0f1e", border:"2px dashed #1a2a4a", borderRadius:12, padding:24, textAlign:"center", cursor:"pointer" }}>
          <div style={{ fontSize:32, marginBottom:8 }}>📷</div>
          <div style={{ fontWeight:700, color:"#8ab", fontSize:13 }}>Take Photo</div>
          <div style={{ color:"#445", fontSize:11, marginTop:4 }}>Use camera</div>
        </div>
      </div>
      <input ref={fileRef} type="file" accept="image/*,.pdf" onChange={handleFile} style={{ display:"none" }}/>
      <p style={{ color:"#445", fontSize:11, textAlign:"center", margin:0 }}>Australian Driver's Licence or Passport • Must clearly show name, DOB, photo and document number</p>
    </div>
  );
}

// ─── Certificate ──────────────────────────────────────────────────────────────
function Certificate({ data }) {
  const refEl = useRef();
  const print = () => {
    const w = window.open("","_blank");
    w.document.write(`<html><head><title>ConsentVault Petition Certificate</title><style>
      body{font-family:Georgia,serif;margin:0;padding:20px;background:#fff;color:#111}
      .cert{border:3px double #0d1e4a;border-radius:8px;padding:32px;max-width:680px;margin:0 auto}
      h1{color:#0d1e4a;font-size:22px;text-align:center;margin-bottom:4px}
      h2{color:#c9a84c;font-size:14px;text-align:center;font-weight:normal;margin-bottom:20px}
      .row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #eee;font-size:13px}
      .lbl{color:#888} .val{font-weight:bold;color:#0d1e4a;text-align:right;max-width:60%}
      .face{width:120px;height:120px;border-radius:8px;object-fit:cover;border:2px solid #c9a84c}
      .lic{width:100%;max-width:300px;border-radius:6px;border:1px solid #ccc;margin-top:8px}
      .sig{width:100%;height:60px;border-radius:6px;border:1px solid #0d1e4a;background:#f9f9f9;margin-top:4px}
      .badge{background:#f0f5ff;border:1px solid #c9a84c;border-radius:6px;padding:12px 16px;font-size:12px;color:#444;margin:16px 0;line-height:1.7}
      .footer{text-align:center;font-size:10px;color:#aaa;margin-top:20px;border-top:1px solid #eee;padding-top:12px}
      .photos{display:flex;gap:20px;align-items:flex-start;margin:12px 0}
      @media print{button{display:none}}
    </style></head><body>
    <div class="cert">
      <h1>🛡️ ConsentVault™ Petition Certificate</h1>
      <h2>Official Petition Signature — Parliamentary Record</h2>
      <div class="badge">
        <strong>PETITION:</strong> To the Honourable the Speaker and Members of the House of Representatives in Parliament Assembled.<br/>
        We the undersigned call on Parliament to: legislate legal defence insurance for accused persons, establish a regulated bail surety industry, mandate digital consent evidence admissibility, and fund an independent review into men's access to legal protection.
      </div>
      <div class="row"><span class="lbl">Full Legal Name</span><span class="val">${data.name}</span></div>
      <div class="row"><span class="lbl">Date of Birth</span><span class="val">${fmtDate(data.dob)}</span></div>
      <div class="row"><span class="lbl">State / Territory</span><span class="val">${data.state}</span></div>
      <div class="row"><span class="lbl">Email Address</span><span class="val">${data.email}</span></div>
      <div class="row"><span class="lbl">Mobile Number</span><span class="val">${data.mobile||"Not provided"}</span></div>
      <div class="row"><span class="lbl">Licence / Passport No.</span><span class="val">${data.docNo||"See image"}</span></div>
      <div class="row"><span class="lbl">Signed At</span><span class="val">${data.signedAt}</span></div>
      <div class="row"><span class="lbl">Session ID</span><span class="val">${data.sessionId}</span></div>
      <br/>
      <strong style="font-size:12px;color:#555">Identity Verification:</strong>
      <div class="photos">
        ${data.face ? `<div><div style="font-size:11px;color:#888;margin-bottom:4px">Facial Verification</div><img class="face" src="${data.face}"/></div>` : ""}
        ${data.licence ? `<div style="flex:1"><div style="font-size:11px;color:#888;margin-bottom:4px">Licence / Passport</div><img class="lic" src="${data.licence}"/></div>` : ""}
      </div>
      <br/>
      <strong style="font-size:12px;color:#555">Signature:</strong>
      ${data.signature ? `<img class="sig" src="${data.signature}"/>` : ""}
      <br/><br/>
      <div class="badge">
        <strong>DECLARATION:</strong> I declare that I am an Australian citizen or permanent resident aged 18 years or older. I am signing this petition voluntarily. I confirm the identity documents and facial verification provided are genuine and belong to me.
      </div>
      <div class="footer">
        ConsentVault Pty Ltd  •  ABN: 52 347 989 391  •  consentvault.com.au<br/>
        This certificate is a record of your petition signature and will be included in the formal submission to the Australian House of Representatives.<br/>
        Session: ${data.sessionId}
      </div>
    </div>
    <div style="text-align:center;margin-top:16px"><button onclick="window.print()" style="background:#0d1e4a;color:#fff;border:none;padding:12px 28px;border-radius:8px;font-size:14px;cursor:pointer">🖨️ Print / Save as PDF</button></div>
    </body></html>`);
    w.document.close(); setTimeout(()=>w.print(),600);
  };

  return (
    <div>
      <div style={{ background:"#fff", border:"3px double #0d1e4a", borderRadius:14, padding:28, fontFamily:"Georgia,serif", color:"#111", marginBottom:20 }}>
        <div style={{ textAlign:"center", borderBottom:"2px solid #0d1e4a", paddingBottom:16, marginBottom:16 }}>
          <div style={{ fontSize:10, letterSpacing:4, color:"#999" }}>CONSENTVAULT™ — OFFICIAL PETITION RECORD</div>
          <div style={{ fontSize:22, fontWeight:700, color:NAVY, margin:"6px 0 4px" }}>Parliamentary Petition Certificate</div>
          <div style={{ fontSize:12, color:"#777" }}>Session: <strong style={{ color:NAVY }}>{data.sessionId}</strong></div>
        </div>
        <div style={{ background:"#f0f5ff", border:"1px solid #c9a84c", borderRadius:8, padding:"12px 16px", fontSize:11, color:"#444", marginBottom:16, lineHeight:1.7 }}>
          <strong>PETITION ADDRESS:</strong> To the Honourable the Speaker and Members of the House of Representatives in Parliament Assembled — requesting legal defence insurance legislation, regulated bail surety industry, digital consent evidence admissibility, and an independent review into men's legal access.
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:16 }}>
          {[[" Full Name",data.name],["Date of Birth",fmtDate(data.dob)],["State",data.state],["Email",data.email],["Mobile",data.mobile||"—"],["Doc No.",data.docNo||"See image"],["Signed",data.signedAt]].map(([l,v])=>(
            <div key={l} style={{ borderBottom:"1px solid #eee", paddingBottom:6, fontSize:12 }}>
              <div style={{ color:"#888", fontSize:10 }}>{l}</div>
              <div style={{ fontWeight:700, color:NAVY, fontSize:13 }}>{v}</div>
            </div>
          ))}
        </div>
        <div style={{ display:"flex", gap:16, marginBottom:16 }}>
          {data.face && <div style={{ textAlign:"center" }}>
            <div style={{ fontSize:10, color:"#888", marginBottom:4 }}>Facial Verification</div>
            <img src={data.face} style={{ width:90, height:90, borderRadius:8, objectFit:"cover", border:`2px solid ${GOLD}` }} alt="face"/>
          </div>}
          {data.licence && <div style={{ flex:1 }}>
            <div style={{ fontSize:10, color:"#888", marginBottom:4 }}>Licence / Passport</div>
            <img src={data.licence} style={{ width:"100%", maxHeight:80, objectFit:"contain", border:"1px solid #ccc", borderRadius:6 }} alt="licence"/>
          </div>}
        </div>
        {data.signature && <div>
          <div style={{ fontSize:10, color:"#888", marginBottom:4 }}>Signature</div>
          <img src={data.signature} style={{ width:"100%", height:60, border:`1px solid ${NAVY}`, borderRadius:6, background:"#f9f9f9" }} alt="sig"/>
        </div>}
        <div style={{ background:"#f5fff8", border:"1px solid #c3e6cb", borderRadius:6, padding:"10px 14px", marginTop:16, fontSize:11, color:"#2a5e3a" }}>
          ✅ I declare this signature is genuine, I am an Australian citizen or permanent resident aged 18+, and I voluntarily support this petition.
        </div>
        <div style={{ textAlign:"center", fontSize:10, color:"#bbb", marginTop:14, borderTop:"1px solid #eee", paddingTop:10 }}>
          ConsentVault Pty Ltd  •  ABN: 52 347 989 391  •  consentvault.com.au
        </div>
      </div>
      <div style={{ display:"flex", gap:10, justifyContent:"center", flexWrap:"wrap" }}>
        <Btn onClick={print} color={NAVY} textColor="#fff" size="lg">🖨️ Print / Download PDF</Btn>
        <Btn onClick={()=>navigator.share?.({ title:"I signed the ConsentVault Petition", url:"https://consentvault.com.au/petition" })} color="#1a5e2a" textColor="#fff">📣 Share I Signed</Btn>
      </div>
    </div>
  );
}

// ─── MAIN FORM ────────────────────────────────────────────────────────────────
export default function PetitionPage() {
  const [step, setStep]   = useState(0);
  const [data, setData]   = useState({ name:"", email:"", mobile:"", dob:"", state:"", docNo:"", face:null, licence:null, signature:null, signedAt:"", sessionId:"" });
  const [count, setCount] = useState(3847);
  const [agree, setAgree] = useState(false);

  const set = (k,v) => setData(d=>({...d,[k]:v}));

  const canNext = [
    data.name && data.email && data.dob && data.state,
    !!data.face,
    !!data.licence,
    agree,
    !!data.signature,
    true
  ];

  const next = () => {
    if (step === 4) {
      set("signedAt", nowStr());
      set("sessionId", "CVP-" + Math.random().toString(36).substr(2,9).toUpperCase());
      setCount(c=>c+1);
    }
    setStep(s=>s+1);
  };

  const states = ["NSW","VIC","QLD","WA","SA","TAS","ACT","NT"];

  const petitionText = `To the Honourable the Speaker and Members of the House of Representatives in Parliament Assembled.

We, the undersigned Australian citizens and residents, call on the Federal Government to:

1. LEGISLATE legal expense insurance that covers criminal defence costs for Australians accused of sexual assault offences.

2. ESTABLISH a regulated commercial bail surety industry in Australia, enabling licensed companies to act as surety for bail applications.

3. MANDATE the legal admissibility of timestamped digital consent records as supporting evidence in sexual consent cases.

4. FUND an independent review into the legal and financial barriers faced by men accused of sexual offences who cannot access bail or adequate legal representation.

These reforms are urgently needed. Men are losing their liberty and accepting unjust plea deals not because they are guilty — but because they cannot afford bail, cannot find a surety, and have no evidence to defend themselves.`;

  return (
    <div style={{ minHeight:"100vh", background:"#07080f", fontFamily:"'Trebuchet MS','Lucida Grande',sans-serif", color:"#c8d8ff" }}>
      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}} .fd{animation:fadeUp 0.3s ease} *{box-sizing:border-box} input:focus,select:focus,textarea:focus{border-color:#c9a84c!important;outline:none} ::-webkit-scrollbar{width:5px;background:#07080f} ::-webkit-scrollbar-thumb{background:#1a2a4a;border-radius:3px}`}</style>

      {/* Header */}
      <div style={{ background:"#07080fee", borderBottom:"1px solid #1a2a4a", padding:"14px 24px", display:"flex", alignItems:"center", gap:14, position:"sticky", top:0, zIndex:100 }}>
        <div style={{ width:36, height:36, background:"linear-gradient(135deg,#1a3aee,#0d1e4a)", borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>🛡️</div>
        <div>
          <div style={{ fontWeight:900, fontSize:16, color:"#c9a84c", fontFamily:"Georgia,serif" }}>ConsentVault</div>
          <div style={{ fontSize:10, color:"#445", letterSpacing:3 }}>PARLIAMENTARY PETITION — consentvault.com.au</div>
        </div>
        <div style={{ marginLeft:"auto", textAlign:"right" }}>
          <div style={{ fontSize:20, fontWeight:900, color:"#4caf50", fontFamily:"Georgia,serif" }}>{count.toLocaleString()}</div>
          <div style={{ fontSize:10, color:"#445" }}>/ 10,000 signatures</div>
        </div>
      </div>

      <div style={{ maxWidth:680, margin:"0 auto", padding:"32px 20px" }}>

        {step < 6 ? (
          <>
            {/* Progress */}
            <StepBar current={step}/>

            {/* Progress bar */}
            <div style={{ height:4, background:"#0a0f1e", borderRadius:2, marginBottom:28 }}>
              <div style={{ height:"100%", background:`linear-gradient(90deg,${NAVY},${GOLD})`, borderRadius:2, width:`${((step)/5)*100}%`, transition:"width 0.4s" }}/>
            </div>

            <div className="fd">

              {/* STEP 0 — Details */}
              {step===0 && (
                <div>
                  <div style={{ fontSize:11, color:GOLD, letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 1 of 6</div>
                  <h2 style={{ fontSize:24, fontWeight:900, color:"#fff", fontFamily:"Georgia,serif", margin:"0 0 6px" }}>Your Personal Details</h2>
                  <p style={{ color:"#556", fontSize:13, marginBottom:24, lineHeight:1.7 }}>Required for official parliamentary petition submission. All details are verified against your identity documents.</p>

                  <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                    <div><Lbl>Full Legal Name *</Lbl><input style={inp} value={data.name} onChange={e=>set("name",e.target.value)} placeholder="As it appears on your licence or passport"/></div>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
                      <div><Lbl>Date of Birth *</Lbl><input type="date" style={inp} value={data.dob} onChange={e=>set("dob",e.target.value)}/></div>
                      <div><Lbl>State / Territory *</Lbl>
                        <select style={inp} value={data.state} onChange={e=>set("state",e.target.value)}>
                          <option value="">Select state</option>
                          {states.map(s=><option key={s}>{s}</option>)}
                        </select>
                      </div>
                    </div>
                    <div><Lbl>Email Address *</Lbl><input type="email" style={inp} value={data.email} onChange={e=>set("email",e.target.value)} placeholder="your@email.com"/></div>
                    <div><Lbl>Mobile Number</Lbl><input style={inp} value={data.mobile} onChange={e=>set("mobile",e.target.value)} placeholder="04XX XXX XXX"/></div>
                    <div><Lbl>Licence / Passport Number</Lbl><input style={inp} value={data.docNo} onChange={e=>set("docNo",e.target.value)} placeholder="e.g. 12345678"/></div>
                  </div>
                </div>
              )}

              {/* STEP 1 — Face */}
              {step===1 && (
                <div>
                  <div style={{ fontSize:11, color:GOLD, letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 2 of 6</div>
                  <h2 style={{ fontSize:24, fontWeight:900, color:"#fff", fontFamily:"Georgia,serif", margin:"0 0 6px" }}>Facial Verification</h2>
                  <p style={{ color:"#556", fontSize:13, marginBottom:24, lineHeight:1.7 }}>Take a clear selfie to verify your identity. This is required for parliamentary petition authenticity — matching your face to your licence/passport.</p>
                  <FaceCapture onCapture={v=>set("face",v)}/>
                </div>
              )}

              {/* STEP 2 — Licence */}
              {step===2 && (
                <div>
                  <div style={{ fontSize:11, color:GOLD, letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 3 of 6</div>
                  <h2 style={{ fontSize:24, fontWeight:900, color:"#fff", fontFamily:"Georgia,serif", margin:"0 0 6px" }}>Licence / Passport Upload</h2>
                  <p style={{ color:"#556", fontSize:13, marginBottom:24, lineHeight:1.7 }}>Upload or photograph your current Australian Driver's Licence or Passport. Must be clearly readable with all 4 corners visible.</p>
                  <LicenceUpload onUpload={v=>set("licence",v)}/>
                  <div style={{ background:"#0d1628", border:"1px solid #1a2a4a", borderRadius:10, padding:"12px 16px", marginTop:20, fontSize:12, color:"#445", lineHeight:1.7 }}>
                    🔒 <strong style={{ color:"#8ab" }}>Privacy:</strong> Your licence image is encrypted end-to-end and stored only for petition verification purposes. It will not be shared publicly — only your name and state appear in the public petition record.
                  </div>
                </div>
              )}

              {/* STEP 3 — Declaration */}
              {step===3 && (
                <div>
                  <div style={{ fontSize:11, color:GOLD, letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 4 of 6</div>
                  <h2 style={{ fontSize:24, fontWeight:900, color:"#fff", fontFamily:"Georgia,serif", margin:"0 0 6px" }}>Read & Agree to Petition</h2>
                  <p style={{ color:"#556", fontSize:13, marginBottom:20, lineHeight:1.7 }}>Please read the full petition text below before signing.</p>

                  <div style={{ background:"#0a0f1e", border:"1px solid #1a2a4a", borderRadius:12, padding:20, marginBottom:20, maxHeight:280, overflowY:"auto" }}>
                    {petitionText.split("\n\n").map((p,i)=>(
                      <p key={i} style={{ fontSize:13, color: i===0?"#c8d8ff":p.match(/^\d\./)?"#c9a84c":"#778", lineHeight:1.8, margin:"0 0 10px", fontWeight: p.match(/^\d\./)?"700":"400" }}>{p}</p>
                    ))}
                  </div>

                  <div style={{ background:"#0d1e0d", border:"1px solid #1a4a1a", borderRadius:12, padding:"16px 20px", marginBottom:20, fontSize:12, color:"#668a66", lineHeight:1.8 }}>
                    <strong style={{ color:"#4caf50" }}>Declaration:</strong> I declare that I am an Australian citizen or permanent resident aged 18 years or older. I am signing voluntarily. I confirm that my identity documents are genuine. I understand my name and state will appear publicly in the petition record. Making a false declaration in a parliamentary petition may constitute an offence.
                  </div>

                  <div onClick={()=>setAgree(!agree)} style={{ display:"flex", gap:14, alignItems:"center", cursor:"pointer", userSelect:"none" }}>
                    <div style={{ width:24, height:24, borderRadius:6, border:`2px solid ${agree?"#4caf50":"#1a2a4a"}`, background:agree?"#1a4a1a":"#0a0f1e", display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, minWidth:24 }}>
                      {agree && "✓"}
                    </div>
                    <span style={{ fontSize:13, color:"#99a", lineHeight:1.6 }}>I have read the full petition text, I agree with the above declaration, and I wish to add my signature to this official parliamentary petition.</span>
                  </div>
                </div>
              )}

              {/* STEP 4 — Signature */}
              {step===4 && (
                <div>
                  <div style={{ fontSize:11, color:GOLD, letterSpacing:3, textTransform:"uppercase", marginBottom:6 }}>Step 5 of 6</div>
                  <h2 style={{ fontSize:24, fontWeight:900, color:"#fff", fontFamily:"Georgia,serif", margin:"0 0 6px" }}>Sign the Petition</h2>
                  <p style={{ color:"#556", fontSize:13, marginBottom:24, lineHeight:1.7 }}>Draw your signature below using your mouse or finger. This is your legal signature on the parliamentary petition.</p>
                  <SigPad onSign={v=>set("signature",v)}/>

                  {/* Preview of their details */}
                  <div style={{ background:"#0d1628", border:"1px solid #1a2a4a", borderRadius:10, padding:"14px 18px", marginTop:20 }}>
                    <div style={{ fontSize:10, color:"#445", letterSpacing:3, textTransform:"uppercase", marginBottom:10 }}>Your Petition Record Preview</div>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                      {[["Name",data.name],["DOB",fmtDate(data.dob)],["State",data.state],["Email",data.email]].map(([l,v])=>(
                        <div key={l} style={{ fontSize:12 }}>
                          <div style={{ color:"#445", fontSize:10 }}>{l}</div>
                          <div style={{ color:"#c8d8ff", fontWeight:700 }}>{v}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ display:"flex", gap:10, marginTop:10 }}>
                      {data.face && <img src={data.face} style={{ width:44, height:44, borderRadius:6, objectFit:"cover", border:`1px solid ${GOLD}` }} alt="f"/>}
                      {data.licence && <img src={data.licence} style={{ height:44, maxWidth:80, borderRadius:6, objectFit:"contain", border:"1px solid #1a2a4a" }} alt="l"/>}
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 5 — Success */}
              {step===5 && (
                <div>
                  <div style={{ textAlign:"center", marginBottom:28 }}>
                    <div style={{ fontSize:56, marginBottom:12 }}>🎉</div>
                    <h2 style={{ fontSize:26, fontWeight:900, color:"#4caf50", fontFamily:"Georgia,serif", margin:"0 0 8px" }}>Petition Signed!</h2>
                    <p style={{ color:"#668a66", fontSize:14, lineHeight:1.8 }}>
                      Thank you <strong style={{ color:"#fff" }}>{data.name}</strong>. Your verified signature has been added to the official ConsentVault Parliamentary Petition. We are now at <strong style={{ color:"#4caf50" }}>{count.toLocaleString()}</strong> signatures.
                    </p>
                    <div style={{ display:"flex", justifyContent:"center", gap:16, flexWrap:"wrap", margin:"16px 0 24px" }}>
                      {[["🎯","Target",`${TARGET.toLocaleString()} sigs`],["📋","Session",data.sessionId],["📅","Signed",new Date().toLocaleDateString("en-AU")]].map(([i,l,v])=>(
                        <div key={l} style={{ background:"#0d1628", border:"1px solid #1a2a4a", borderRadius:10, padding:"10px 18px", textAlign:"center" }}>
                          <div style={{ fontSize:20 }}>{i}</div>
                          <div style={{ fontSize:10, color:"#445", letterSpacing:2 }}>{l}</div>
                          <div style={{ fontSize:13, color:"#c9a84c", fontWeight:700 }}>{v}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <Certificate data={{ ...data, signedAt: data.signedAt||nowStr(), sessionId: data.sessionId||"CVP-DEMO" }}/>
                </div>
              )}
            </div>

            {step < 5 && (
              <div style={{ marginTop:28, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                {step>0 ? <Btn onClick={()=>setStep(s=>s-1)} color="#1a2a4a" textColor="#8ab">← Back</Btn> : <div/>}
                <Btn onClick={next} disabled={!canNext[step]} color={GOLD} textColor="#07080f" size="lg">
                  {step===4 ? "✍️ Submit Signature →" : "Next →"}
                </Btn>
              </div>
            )}
          </>
        ) : null}

        {/* Counter always visible at bottom */}
        {step < 5 && (
          <div style={{ marginTop:32, background:"#0d1628", border:"1px solid #1a2a4a", borderRadius:12, padding:"16px 20px", display:"flex", gap:16, alignItems:"center" }}>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                <span style={{ fontSize:13, color:"#c9a84c", fontWeight:800 }}>{count.toLocaleString()} signatures</span>
                <span style={{ fontSize:12, color:"#445" }}>Target: 10,000</span>
              </div>
              <div style={{ height:8, background:"#0a0f1e", borderRadius:4, overflow:"hidden" }}>
                <div style={{ height:"100%", background:"linear-gradient(90deg,#1a8a2a,#4caf50)", borderRadius:4, width:`${Math.min((count/10000)*100,100)}%`, transition:"width 0.8s" }}/>
              </div>
            </div>
            <div style={{ fontSize:11, color:"#445", textAlign:"right", minWidth:100 }}>
              <div style={{ fontWeight:700, color:"#c8d8ff" }}>{(10000-count).toLocaleString()} more</div>
              <div>needed for parliament</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const TARGET = 10000;

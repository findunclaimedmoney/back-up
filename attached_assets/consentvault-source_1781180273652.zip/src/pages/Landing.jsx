import { useState, useEffect, useRef } from 'react'

const NAVY="#0d1e4a", GOLD="#c9a84c", GREEN="#1a5e2a"

// ─── Animated Counter ─────────────────────────────────────────────────────────
function AnimCounter({ target, duration=2000, prefix="", suffix="" }) {
  const [val, setVal] = useState(0)
  const ref = useRef()
  const started = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true
        const start = Date.now()
        const tick = () => {
          const elapsed = Date.now() - start
          const pct = Math.min(elapsed / duration, 1)
          const ease = 1 - Math.pow(1 - pct, 3)
          setVal(Math.round(ease * target))
          if (pct < 1) requestAnimationFrame(tick)
        }
        requestAnimationFrame(tick)
      }
    }, { threshold: 0.3 })
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [target, duration])

  const fmt = (n) => n >= 1000 ? n.toLocaleString('en-AU') : n

  return <span ref={ref}>{prefix}{fmt(val)}{suffix}</span>
}

// ─── Logo ─────────────────────────────────────────────────────────────────────
const VaultLogo = ({ size=44 }) => (
  <div style={{display:"flex",alignItems:"center",gap:12}}>
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <circle cx="50" cy="50" r="48" fill="#07080f" stroke="#c9a84c" strokeWidth="3"/>
      <rect x="18" y="20" width="64" height="60" rx="6" fill="#0d1628" stroke="#c9a84c" strokeWidth="2.5"/>
      <circle cx="50" cy="50" r="18" fill="none" stroke="#c9a84c" strokeWidth="3"/>
      <line x1="50" y1="32" x2="50" y2="68" stroke="#c9a84c" strokeWidth="2.5"/>
      <line x1="32" y1="50" x2="68" y2="50" stroke="#c9a84c" strokeWidth="2.5"/>
      <line x1="37" y1="37" x2="63" y2="63" stroke="#c9a84c" strokeWidth="2"/>
      <line x1="63" y1="37" x2="37" y2="63" stroke="#c9a84c" strokeWidth="2"/>
      <circle cx="50" cy="50" r="6" fill="#c9a84c"/>
      <circle cx="22" cy="30" r="3" fill="#c9a84c"/>
      <circle cx="22" cy="70" r="3" fill="#c9a84c"/>
      <rect x="72" y="46" width="6" height="8" rx="2" fill="#c9a84c"/>
    </svg>
    <div>
      <div style={{fontFamily:"Georgia,serif",fontWeight:900,fontSize:size*0.42,color:GOLD,letterSpacing:1,lineHeight:1}}>ConsentVault</div>
      <div style={{fontSize:size*0.16,color:"#3a5aaa",letterSpacing:3,textTransform:"uppercase"}}>consentvault.com.au</div>
    </div>
  </div>
)

const Tag = ({color=GOLD,children}) => (
  <span style={{background:color+"18",color,border:`1px solid ${color}44`,borderRadius:20,padding:"4px 14px",fontSize:11,fontWeight:800,letterSpacing:2,textTransform:"uppercase"}}>{children}</span>
)

const Btn = ({onClick,color=GOLD,textColor="#07080f",children,full,size="md"}) => (
  <button onClick={onClick} style={{background:color,color:textColor,border:"none",borderRadius:10,cursor:"pointer",padding:size==="lg"?"16px 32px":"12px 22px",fontSize:size==="lg"?16:14,fontWeight:800,fontFamily:"inherit",width:full?"100%":undefined,letterSpacing:0.5,transition:"opacity 0.2s"}}
    onMouseEnter={e=>e.currentTarget.style.opacity="0.85"} onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
    {children}
  </button>
)

// ─── Gender Bar ───────────────────────────────────────────────────────────────
function GenderBar({ maleCount, femaleCount }) {
  const total = maleCount + femaleCount
  const malePct = ((maleCount / total) * 100).toFixed(1)
  const femalePct = ((femaleCount / total) * 100).toFixed(1)
  const barRef = useRef()
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) setAnimate(true)
    }, { threshold: 0.3 })
    if (barRef.current) observer.observe(barRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <div ref={barRef}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:12,height:12,borderRadius:3,background:"#e53"}}/>
          <span style={{fontSize:13,color:"#c8d8ff",fontWeight:700}}>Male — {malePct}%</span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:13,color:"#c8d8ff",fontWeight:700}}>{femalePct}% — Female</span>
          <div style={{width:12,height:12,borderRadius:3,background:"#4a9aee"}}/>
        </div>
      </div>
      <div style={{height:28,background:"#0a0f1e",borderRadius:14,overflow:"hidden",border:"1px solid #1a2a4a",display:"flex"}}>
        <div style={{height:"100%",background:"linear-gradient(90deg,#c0392b,#e53935)",width:animate?`${malePct}%`:"0%",transition:"width 2s cubic-bezier(0.4,0,0.2,1)",display:"flex",alignItems:"center",justifyContent:"center"}}>
          <span style={{fontSize:12,fontWeight:800,color:"#fff",whiteSpace:"nowrap",padding:"0 8px"}}>{malePct}%</span>
        </div>
        <div style={{height:"100%",background:"linear-gradient(90deg,#1565c0,#4a9aee)",flex:1,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <span style={{fontSize:12,fontWeight:800,color:"#fff",whiteSpace:"nowrap",padding:"0 8px"}}>{femalePct}%</span>
        </div>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",marginTop:6,fontSize:11,color:"#445"}}>
        <span>{maleCount.toLocaleString('en-AU')} men</span>
        <span>{femaleCount.toLocaleString('en-AU')} women</span>
      </div>
    </div>
  )
}

// ─── State Bar Chart ──────────────────────────────────────────────────────────
function StateChart() {
  const barRef = useRef()
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) setAnimate(true)
    }, { threshold: 0.2 })
    if (barRef.current) observer.observe(barRef.current)
    return () => observer.disconnect()
  }, [])

  const states = [
    { state:"NSW", count:13164, color:"#e53935" },
    { state:"QLD", count:11278, color:"#c9a84c" },
    { state:"VIC", count:6593,  color:"#4a9aee" },
    { state:"WA",  count:7200,  color:"#4caf50" },
    { state:"SA",  count:3800,  color:"#e88" },
    { state:"TAS", count:820,   color:"#9c6" },
    { state:"ACT", count:380,   color:"#6cf" },
    { state:"NT",  count:2000,  color:"#fa8" },
  ]
  const max = Math.max(...states.map(s=>s.count))

  return (
    <div ref={barRef} style={{display:"flex",flexDirection:"column",gap:10}}>
      {states.map(({state,count,color})=>(
        <div key={state} style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:32,fontSize:11,color:"#667",fontWeight:700,flexShrink:0}}>{state}</div>
          <div style={{flex:1,height:20,background:"#0a0f1e",borderRadius:6,overflow:"hidden",border:"1px solid #1a2a4a"}}>
            <div style={{height:"100%",background:color,borderRadius:6,width:animate?`${(count/max)*100}%`:"0%",transition:"width 1.5s cubic-bezier(0.4,0,0.2,1)",transitionDelay:`${states.findIndex(s=>s.state===state)*0.1}s`}}/>
          </div>
          <div style={{width:48,fontSize:11,color:color,fontWeight:700,textAlign:"right",flexShrink:0}}>{count.toLocaleString('en-AU')}</div>
        </div>
      ))}
    </div>
  )
}

// ─── Blinking live dot ────────────────────────────────────────────────────────
const LiveDot = ({color="#4caf50"}) => (
  <span style={{display:"inline-block",width:8,height:8,borderRadius:"50%",background:color,marginRight:6,animation:"blink 1.5s infinite"}}/>
)

export default function Landing({onNav}) {
  const [billing,setBilling]=useState(true)
  const [faqOpen,setFaqOpen]=useState(null)

  const plans=[
    {name:"Shield Basic",tag:"For Men",price:billing?"$7.42":"$9.99",annual:billing?"$89/yr":null,highlight:false,cta:"Get Basic Shield",
      features:["Unlimited QR consent sessions","GPS + facial ID capture","Timestamped video consent","PDF legal certificate","12-month secure backup","Certificate emailed to both","SOS lock screen widget","3 surety contact slots"]},
    {name:"Shield Pro",tag:"Most Popular",price:billing?"$24.08":"$28.99",annual:billing?"$289/yr":null,highlight:true,cta:"Get Shield Pro →",
      features:["Everything in Basic","Automated court monitoring","Daily name scan — all states","Pre-recorded emergency voice call","Surety contact pre-verification","Surety-ready document package","24/7 bail lawyer hotline","Court appearance alerts — SMS + call"]},
    {name:"Shield Elite",tag:"Full Protection",price:billing?"$39.92":"$47.99",annual:billing?"$479/yr":null,highlight:false,cta:"Get Elite Shield",
      features:["Everything in Pro","Inactivity dead man's switch","Multi-surety joint coordination","Priority evidence retrieval","Court appearance live tracking","Children's emergency fund link","Insurance waitlist priority","Dedicated case manager on arrest"]},
    {name:"Safe Plan",tag:"For Women",price:billing?"$3.25":"$4.99",annual:billing?"$39/yr":null,highlight:false,cta:"Get Safe Plan",
      features:["Receive consent certificates","12-month backup","Post-encounter wellness pack","Withdraw/flag a session","Anonymous reporting pathway","Certificate access anytime"]},
  ]

  const faqs=[
    ["Is this admissible in Australian courts?","ConsentVault creates a timestamped, GPS-verified, biometric-confirmed, spoken video record of mutual consent. No app can guarantee court outcomes — only a solicitor can advise on specific cases. However, a contemporaneous video declaration with GPS and facial ID is significantly stronger evidence than nothing. Consult a criminal defence solicitor for case-specific advice."],
    ["Does she need to download an app?","No. She scans your QR code on her phone's camera and it opens in her mobile browser. Nothing to download, nothing to install. The entire process takes under 3 minutes on her phone."],
    ["What is the archive retrieval fee?","If your subscription lapses, your records move to cold archive storage. Retrieval requires forensic extraction, chain-of-custody documentation, legal-grade PDF regeneration, and a notarised certificate of authenticity required for court admissibility. Retrieval fee: $2,200. Keep your subscription active for $89/year instead."],
    ["What happens when I'm arrested?","One tap on your lock screen widget fires voice calls to all 3 surety contacts, shares your GPS location, emails the surety package, and dials your bail lawyer. If you can't tap, our automated court name monitoring detects your appearance and fires the same alert."],
    ["What is the parliamentary petition?","ConsentVault is collecting 10,000 verified signatures to present to the Australian House of Representatives. Under parliamentary rules, 10,000 signatures forces a mandatory Legislative Review Committee investigation into bail surety reform, legal defence insurance, and digital consent evidence admissibility."],
  ]

  return (
    <div style={{background:"#07080f",minHeight:"100vh",fontFamily:"'Trebuchet MS','Lucida Grande',sans-serif",color:"#c8d8ff"}}>
      <style>{`
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:5px;background:#07080f}
        ::-webkit-scrollbar-thumb{background:#1a2a4a;border-radius:3px}
        @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0.2}}
        @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.04)}}
        .fade{animation:fadeUp 0.5s ease}
      `}</style>

      {/* NAV */}
      <nav style={{position:"sticky",top:0,zIndex:100,background:"#07080fee",backdropFilter:"blur(14px)",borderBottom:"1px solid #1a2a4a",padding:"12px 24px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}>
        <VaultLogo size={36}/>
        <div style={{display:"flex",gap:20,fontSize:12,color:"#556",flexWrap:"wrap"}}>
          {[["How It Works","#how"],["Prison Stats","#prison-stats"],["Pricing","#pricing"],["SOS Alert","#sos"],["Petition","#petition"]].map(([l,h])=>(
            <a key={l} href={h} style={{color:"#556",textDecoration:"none"}} onMouseEnter={e=>e.target.style.color=GOLD} onMouseLeave={e=>e.target.style.color="#556"}>{l}</a>
          ))}
        </div>
        <div style={{display:"flex",gap:8}}>
          <Btn onClick={()=>onNav('app')} color="#1a2a5e" textColor="#c8d8ff">Open App</Btn>
          <Btn onClick={()=>onNav('petition')} color={GOLD} textColor="#07080f">Sign Petition</Btn>
        </div>
      </nav>

      {/* HERO */}
      <section className="fade" style={{maxWidth:1100,margin:"0 auto",padding:"80px 24px 60px",textAlign:"center"}}>
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap",marginBottom:28}}>
          <Tag color="#4a9aee">🤝 Men's Rights Agency Aligned</Tag>
          <Tag color="#4caf50">📋 Parliamentary Petition Active</Tag>
          <Tag color={GOLD}>⚖️ Evidence-Grade Legal Record</Tag>
          <Tag color="#e88">🚨 SOS Arrest Alert System</Tag>
        </div>
        <h1 style={{fontSize:"clamp(28px,5vw,54px)",fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",lineHeight:1.15,margin:"0 auto 20px",maxWidth:860}}>
          Your Consent. <span style={{color:GOLD}}>Locked.</span><br/>
          Your Evidence. <span style={{color:GOLD}}>Proven.</span><br/>
          Your People. <span style={{color:"#4caf50"}}>Alerted.</span>
        </h1>
        <p style={{fontSize:17,color:"#778",maxWidth:600,margin:"0 auto 32px",lineHeight:1.9}}>
          Australia's only legally-structured mutual consent vault — with automated arrest detection, court monitoring, emergency surety activation, and a growing parliamentary petition for men's legal rights reform.
        </p>
        <div style={{display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap",marginBottom:36}}>
          <Btn onClick={()=>onNav('app')} color={GOLD} textColor="#07080f" size="lg">🛡️ Start Free 7-Day Trial</Btn>
          <Btn onClick={()=>onNav('petition')} color="transparent" textColor="#c8d8ff" size="lg">✍️ Sign the Petition</Btn>
        </div>
        <div style={{display:"flex",gap:20,justifyContent:"center",flexWrap:"wrap",fontSize:12,color:"#334"}}>
          {["🔒 End-to-End Encrypted","🇦🇺 Australian Servers","📍 GPS Verified","🤳 Facial ID","🚨 SOS Arrest Alert","👥 Surety Network"].map(t=><span key={t}>{t}</span>)}
        </div>
      </section>

      {/* EXISTING STATS */}
      <div style={{background:"#0a0f1e",borderTop:"1px solid #1a2a4a",borderBottom:"1px solid #1a2a4a"}}>
        <div style={{maxWidth:1100,margin:"0 auto",padding:"52px 24px"}}>
          <div style={{textAlign:"center",marginBottom:36}}>
            <div style={{fontSize:11,color:GOLD,letterSpacing:4,textTransform:"uppercase",marginBottom:8}}>Why This Exists</div>
            <h2 style={{fontSize:28,fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:0}}>The Numbers That Built ConsentVault</h2>
          </div>
          <div style={{display:"flex",gap:14,flexWrap:"wrap"}}>
            {[["77%","Guilty Outcomes","Of sexual assault cases reaching a court ruling in Australia","#e53"],
              ["14 yrs","Maximum Sentence","For sexual intercourse without consent — standard non-parole: 7 years","#e88"],
              ["4.5 yrs","Average Prison Term","Served by those convicted — rising every year","#c9a84c"],
              ["62%","Wrongful Convictions","Involve false allegations or perjury — National Registry of Exonerations","#4a9aee"],
              ["87.7%","AVO Breach Cases","Are men — yet making a false AVO is NOT a criminal offence","#4caf50"],
              ["$2,200","Archive Retrieval","Cost to recover lapsed evidence — keep subscription active","#e53"],
            ].map(([n,l,s,c])=>(
              <div key={l} style={{background:"#0d1628",border:`1px solid ${c}22`,borderRadius:14,padding:"22px 18px",textAlign:"center",flex:1,minWidth:150}}>
                <div style={{fontSize:32,fontWeight:900,color:c,fontFamily:"Georgia,serif",lineHeight:1}}>{n}</div>
                <div style={{fontSize:13,fontWeight:700,color:"#c8d8ff",margin:"6px 0 4px"}}>{l}</div>
                <div style={{fontSize:11,color:"#334",lineHeight:1.5}}>{s}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── PRISON POPULATION SECTION (NEW) ── */}
      <section id="prison-stats" style={{maxWidth:1100,margin:"0 auto",padding:"80px 24px"}}>

        {/* Section header */}
        <div style={{textAlign:"center",marginBottom:56}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:12}}>
            <LiveDot color="#e53"/>
            <span style={{fontSize:11,color:"#e53",letterSpacing:4,textTransform:"uppercase",fontWeight:700}}>Live Australian Prison Data — ABS 2025/2026</span>
          </div>
          <h2 style={{fontSize:"clamp(26px,4vw,40px)",fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:"0 0 14px"}}>
            Right Now. Tonight. In Australia.
          </h2>
          <p style={{color:"#667",fontSize:15,maxWidth:620,margin:"0 auto",lineHeight:1.9}}>
            These aren't statistics from a distant country. These are your fellow Australians — fathers, brothers, sons — sitting in cells right now. Many convicted on little more than someone else's word.
          </p>
        </div>

        {/* BIG LIVE COUNTER ROW */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:16,marginBottom:40}}>
          {[
            { num:47379, label:"Australians In Prison", sub:"Average daily number — Dec Quarter 2025", color:"#e53935", prefix:"", suffix:"", source:"ABS Dec Qtr 2025" },
            { num:43609, label:"Men Behind Bars", sub:"92% of all Australian prisoners are male", color:"#c9a84c", prefix:"", suffix:"", source:"ABS June 2025" },
            { num:3831,  label:"Women Behind Bars", sub:"8% of total — female imprisonment up 12% in 2025", color:"#4a9aee", prefix:"", suffix:"", source:"ABS June 2025" },
            { num:19850, label:"Unsentenced on Remand", sub:"Not convicted — couldn't get bail or surety", color:"#ff6b6b", prefix:"", suffix:"", source:"ABS June 2025" },
          ].map(({num,label,sub,color,prefix,suffix,source})=>(
            <div key={label} style={{background:"#0a0f1e",border:`2px solid ${color}33`,borderRadius:16,padding:"28px 20px",textAlign:"center",position:"relative",overflow:"hidden"}}>
              <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:color}}/>
              <div style={{fontSize:"clamp(28px,4vw,44px)",fontWeight:900,color,fontFamily:"Georgia,serif",lineHeight:1,marginBottom:8}}>
                <AnimCounter target={num} duration={2500} prefix={prefix} suffix={suffix}/>
              </div>
              <div style={{fontSize:14,fontWeight:800,color:"#c8d8ff",marginBottom:6}}>{label}</div>
              <div style={{fontSize:11,color:"#445",lineHeight:1.5,marginBottom:8}}>{sub}</div>
              <div style={{fontSize:9,color:"#2a3a5a",letterSpacing:1.5,textTransform:"uppercase"}}>{source}</div>
            </div>
          ))}
        </div>

        {/* GENDER BREAKDOWN + STATE CHART */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24,marginBottom:40}}>

          {/* Gender breakdown */}
          <div style={{background:"#0a0f1e",border:"1px solid #1a2a4a",borderRadius:16,padding:28}}>
            <div style={{fontSize:11,color:GOLD,letterSpacing:3,textTransform:"uppercase",marginBottom:6}}>Gender Breakdown</div>
            <h3 style={{fontSize:20,fontWeight:800,color:"#fff",fontFamily:"Georgia,serif",margin:"0 0 20px"}}>92% Male. 8% Female.</h3>
            <GenderBar maleCount={43609} femaleCount={3831}/>
            <div style={{marginTop:20,display:"flex",flexDirection:"column",gap:10}}>
              {[
                ["Male imprisonment rate","390.6 per 100,000 men","#e53"],
                ["Female imprisonment rate","34.7 per 100,000 women","#4a9aee"],
                ["Male prisoners up","5% in 2025","#c9a84c"],
                ["Female prisoners up","12% in 2025 — fastest rising","#ff6b6b"],
              ].map(([l,v,c])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:"1px solid #0d1220",fontSize:12}}>
                  <span style={{color:"#556"}}>{l}</span>
                  <span style={{color:c,fontWeight:700}}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{marginTop:14,background:"#070810",border:"1px solid #1a2a4a",borderRadius:8,padding:"10px 14px",fontSize:11,color:"#445",lineHeight:1.6}}>
              Source: ABS Prisoners in Australia 2025 (released 11 Dec 2025) & ABS Corrective Services Australia Dec Quarter 2025
            </div>
          </div>

          {/* State chart */}
          <div style={{background:"#0a0f1e",border:"1px solid #1a2a4a",borderRadius:16,padding:28}}>
            <div style={{fontSize:11,color:GOLD,letterSpacing:3,textTransform:"uppercase",marginBottom:6}}>By State & Territory</div>
            <h3 style={{fontSize:20,fontWeight:800,color:"#fff",fontFamily:"Georgia,serif",margin:"0 0 20px"}}>Prisoners by Jurisdiction</h3>
            <StateChart/>
            <div style={{marginTop:16,display:"flex",flexDirection:"column",gap:8}}>
              {[
                ["NSW","13,164","↑ 2%","#e53"],
                ["QLD","11,278","↑ 4%","#c9a84c"],
                ["VIC","6,593","↑ 11% — fastest growth","#4a9aee"],
              ].map(([s,n,change,c])=>(
                <div key={s} style={{display:"flex",gap:8,alignItems:"center",fontSize:12}}>
                  <span style={{color:c,fontWeight:800,minWidth:32}}>{s}</span>
                  <span style={{color:"#c8d8ff",fontWeight:700}}>{n} prisoners</span>
                  <span style={{color:c,fontSize:11}}>{change}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* REMAND CALLOUT */}
        <div style={{background:"linear-gradient(135deg,#1a0808,#0a0814)",border:"2px solid #ff6b6b44",borderRadius:18,padding:"36px 40px",marginBottom:40}}>
          <div style={{display:"flex",gap:24,alignItems:"flex-start",flexWrap:"wrap"}}>
            <div style={{fontSize:56,lineHeight:1}}>⚠️</div>
            <div style={{flex:1}}>
              <div style={{fontSize:11,color:"#ff6b6b",letterSpacing:4,textTransform:"uppercase",marginBottom:8}}>
                <LiveDot color="#ff6b6b"/>The Remand Crisis
              </div>
              <h3 style={{fontSize:"clamp(18px,3vw,26px)",fontWeight:900,color:"#fff",fontFamily:"Georgia,serif",margin:"0 0 12px"}}>
                19,850 Australians In Prison Without Being Convicted
              </h3>
              <p style={{color:"#aa8888",fontSize:14,lineHeight:1.9,margin:"0 0 20px"}}>
                These are <strong style={{color:"#ffaaaa"}}>unsentenced prisoners on remand</strong> — they have been charged but not convicted of anything. Many are there for one reason only: <strong style={{color:"#ffaaaa"}}>they couldn't find a surety to guarantee their court appearance.</strong>
              </p>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:12}}>
                {[
                  ["19,850","Unsentenced prisoners","Unable to get bail","#ff6b6b"],
                  ["↑ 10%","Remand increase","In just 12 months — 2024 to 2025","#e88"],
                  ["$1K–$1M","Surety range","Most can't find anyone to cover it","#c9a84c"],
                  ["Months","Average wait","Sitting in remand before trial even starts","#4a9aee"],
                ].map(([n,l,s,c])=>(
                  <div key={l} style={{background:"#200808",border:`1px solid ${c}33`,borderRadius:10,padding:"14px 16px",textAlign:"center"}}>
                    <div style={{fontSize:22,fontWeight:900,color:c,fontFamily:"Georgia,serif"}}>{n}</div>
                    <div style={{fontSize:12,fontWeight:700,color:"#c8d8ff",margin:"4px 0 3px"}}>{l}</div>
                    <div style={{fontSize:10,color:"#554",lineHeight:1.4}}>{s}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* SEXUAL ASSAULT PRISONERS */}
        <div style={{background:"#0a0f1e",border:"1px solid #1a2a4a",borderRadius:18,padding:"36px 40px",marginBottom:40}}>
          <div style={{textAlign:"center",marginBottom:28}}>
            <div style={{fontSize:11,color:"#e88",letterSpacing:4,textTransform:"uppercase",marginBottom:8}}>Sexual Assault Imprisonment</div>
            <h3 style={{fontSize:"clamp(18px,3vw,26px)",fontWeight:900,color:"#fff",fontFamily:"Georgia,serif",margin:"0 0 10px"}}>
              Thousands Imprisoned for Sexual Offences Annually
            </h3>
            <p style={{color:"#667",fontSize:13,maxWidth:560,margin:"0 auto",lineHeight:1.7}}>
              Sexual assault and related offences are the <strong style={{color:"#e88"}}>2nd most common</strong> serious offence across Australia's two largest prison populations.
            </p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:16,marginBottom:24}}>
            {[
              ["2,437","NSW Prisoners","Sexual assault is 19% of NSW's prison population","#e53","NSW"],
              ["1,233","VIC Prisoners","Sexual assault is 19% of Victoria's prison population","#4a9aee","VIC"],
              ["2nd","Most Serious Offence","Across both NSW and VIC — second only to acts of violence","#e88","AUS"],
              ["92%","Are Male","Of all sexual assault prisoners — consistent across all states","#c9a84c","AUS"],
            ].map(([n,l,s,c,state])=>(
              <div key={l} style={{background:"#07080f",border:`1px solid ${c}33`,borderRadius:12,padding:"20px 18px",textAlign:"center"}}>
                <div style={{fontSize:9,color:c,letterSpacing:3,textTransform:"uppercase",marginBottom:6}}>{state}</div>
                <div style={{fontSize:34,fontWeight:900,color:c,fontFamily:"Georgia,serif",lineHeight:1,marginBottom:6}}>{n}</div>
                <div style={{fontSize:13,fontWeight:700,color:"#c8d8ff",marginBottom:4}}>{l}</div>
                <div style={{fontSize:11,color:"#445",lineHeight:1.5}}>{s}</div>
              </div>
            ))}
          </div>
          <div style={{background:"#0d1628",border:"1px solid #2a2a4a",borderRadius:10,padding:"16px 20px",fontSize:13,color:"#778",lineHeight:1.8,textAlign:"center"}}>
            📖 Sources: ABS <em>Prisoners in Australia 2025</em> (released 11 Dec 2025) — NSW: 2,437 sexual assault prisoners (19% of 13,164) | VIC: 1,233 sexual assault prisoners (19% of 6,593)
          </div>
        </div>

        {/* WHAT THIS MEANS */}
        <div style={{background:"linear-gradient(135deg,#0a1e0a,#0a1628)",border:"2px solid #4caf5044",borderRadius:18,padding:"36px 40px"}}>
          <div style={{display:"flex",gap:20,alignItems:"flex-start",flexWrap:"wrap"}}>
            <div style={{fontSize:48}}>🛡️</div>
            <div style={{flex:1}}>
              <div style={{fontSize:11,color:"#4caf50",letterSpacing:4,textTransform:"uppercase",marginBottom:8}}>What This Means for You</div>
              <h3 style={{fontSize:"clamp(18px,3vw,24px)",fontWeight:900,color:"#fff",fontFamily:"Georgia,serif",margin:"0 0 12px"}}>
                ConsentVault Was Built for These Numbers
              </h3>
              <p style={{color:"#668a66",fontSize:14,lineHeight:1.9,margin:"0 0 20px"}}>
                47,379 Australians in prison tonight. 43,600 of them are men. Nearly 20,000 are there without being convicted — sitting on remand because they couldn't find a surety. And when it comes to sexual assault cases, the entire outcome rests on one thing: <strong style={{color:"#4caf50"}}>whose word the jury believes.</strong>
              </p>
              <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
                <Btn onClick={()=>onNav('app')} color="#4caf50" textColor="#fff" size="lg">🛡️ Protect Yourself Now</Btn>
                <Btn onClick={()=>onNav('petition')} color="#1a2a5e" textColor="#c8d8ff" size="lg">✍️ Sign the Petition</Btn>
              </div>
            </div>
          </div>
        </div>

      </section>

      {/* HOW IT WORKS */}
      <section id="how" style={{maxWidth:1100,margin:"0 auto",padding:"72px 24px"}}>
        <div style={{background:"#0a0f1e",borderRadius:18,padding:"28px 32px",marginBottom:40,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:16,border:"1px solid #1a2a4a"}}>
          <div>
            <div style={{fontSize:11,color:GOLD,letterSpacing:3,textTransform:"uppercase",marginBottom:4}}>The Process</div>
            <h2 style={{fontSize:28,fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:0}}>Six Steps. Total Protection.</h2>
          </div>
          <Btn onClick={()=>onNav('app')} color={GOLD} textColor="#07080f" size="lg">🚀 Try the App Now</Btn>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))",gap:24}}>
          {[["📱","1","Generate QR Code","Enter your name and get an instant session QR code pre-filled with your name and date"],
            ["🤳","2","She Scans Her Phone","She scans on her own device — opens in browser, no app needed. GPS + facial ID captured on her device"],
            ["🎥","3","She Records Consent","She reads a legal script on camera: 'I freely consent to an encounter with [your name]...' — timestamped"],
            ["🔒","4","Session Locked","Unique session ID created. Emailed to both parties instantly. Evidence locked in vault"],
            ["⏱","5","Timer Runs","Active session timer. Both parties can close the session at any time"],
            ["📜","6","Certificate Generated","Both record closing statements. PDF legal certificate with GPS, facial ID, timestamps — emailed to both"],
          ].map(([icon,n,title,desc])=>(
            <div key={n} style={{background:"#0d1628",border:"1px solid #1a2a4a",borderRadius:14,padding:22}}>
              <div style={{display:"flex",gap:12,alignItems:"center",marginBottom:12}}>
                <div style={{width:44,height:44,background:"#0a0f1e",border:"1px solid #c9a84c33",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>{icon}</div>
                <div style={{fontSize:10,color:GOLD,letterSpacing:3,fontWeight:700}}>STEP {n}</div>
              </div>
              <div style={{fontWeight:700,color:"#c8d8ff",fontSize:15,marginBottom:6}}>{title}</div>
              <div style={{fontSize:12,color:"#556",lineHeight:1.7}}>{desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* SOS SYSTEM */}
      <div id="sos" style={{background:"#0a0f1e",borderTop:"1px solid #1a2a4a",borderBottom:"1px solid #1a2a4a"}}>
        <div style={{maxWidth:1100,margin:"0 auto",padding:"72px 24px"}}>
          <div style={{textAlign:"center",marginBottom:48}}>
            <div style={{fontSize:11,color:"#e53",letterSpacing:4,textTransform:"uppercase",marginBottom:10}}>🚨 Arrest Alert System</div>
            <h2 style={{fontSize:32,fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:"0 0 14px"}}>If You're Arrested — Your People Know Immediately</h2>
            <p style={{color:"#667",fontSize:15,maxWidth:560,margin:"0 auto"}}>Three automated triggers fire the moment something goes wrong — whether you have 30 seconds with your phone or it's taken immediately.</p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))",gap:20,marginBottom:32}}>
            {[["🔴","One-Tap SOS","Lock Screen Widget","One tap fires voice calls to all 3 surety contacts, shares GPS location, emails the surety package, and dials your bail lawyer. Works with just 10 seconds.","#e53"],
              ["🟡","Court Name Scan","Automated Daily Monitoring","ConsentVault scans your name against all Australian state court daily lists every morning at 6am. The moment your name appears — contacts are called with the court name, date and time.","#c9a84c"],
              ["🟢","Dead Man's Switch","18-Hour Inactivity Alert","If your app hasn't checked in for 18 hours and you haven't marked yourself safe — a welfare alert fires to all contacts who can then activate your full surety package.","#4caf50"],
            ].map(([dot,title,sub,desc,color])=>(
              <div key={title} style={{background:"#07080f",border:`1px solid ${color}33`,borderRadius:14,padding:24}}>
                <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:14}}>
                  <div style={{width:12,height:12,borderRadius:"50%",background:color,animation:"blink 2s infinite"}}/>
                  <div>
                    <div style={{fontWeight:800,color:"#c8d8ff",fontSize:14}}>{title}</div>
                    <div style={{fontSize:11,color,letterSpacing:2}}>{sub}</div>
                  </div>
                </div>
                <div style={{fontSize:13,color:"#556",lineHeight:1.8}}>{desc}</div>
              </div>
            ))}
          </div>
          <div style={{background:"linear-gradient(135deg,#0d1e0d,#0a1628)",border:"1px solid #2a4a2a",borderRadius:14,padding:"28px 32px",display:"flex",gap:20,alignItems:"center",flexWrap:"wrap"}}>
            <div style={{fontSize:44}}>🎙️</div>
            <div style={{flex:1}}>
              <div style={{fontSize:11,color:"#4caf50",letterSpacing:3,textTransform:"uppercase",marginBottom:6}}>Pre-Recorded Personal Voice Message</div>
              <h4 style={{fontSize:18,fontWeight:800,color:"#fff",margin:"0 0 8px",fontFamily:"Georgia,serif"}}>They Hear Your Voice. Not a Robot. Not a Text.</h4>
              <p style={{color:"#668a66",fontSize:13,lineHeight:1.8,margin:0}}>
                At signup you record two personal voice messages — one for arrest, one for court appearance. When triggered, contacts receive a phone call in your voice: <em style={{color:"#7acf7a"}}>"Hey Dad, I've been arrested. ConsentVault sent you everything. Open the email now..."</em>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* PETITION */}
      <section id="petition" style={{maxWidth:1100,margin:"0 auto",padding:"72px 24px"}}>
        <div style={{background:"linear-gradient(135deg,#0d1e0d,#0a1628)",border:"2px solid #4caf5044",borderRadius:20,padding:"48px 40px",textAlign:"center"}}>
          <div style={{fontSize:11,color:"#4caf50",letterSpacing:4,textTransform:"uppercase",marginBottom:12}}>🏛️ Parliamentary Petition</div>
          <h2 style={{fontSize:32,fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:"0 0 16px"}}>10,000 Signatures Forces Parliament to Act</h2>
          <p style={{color:"#668a66",fontSize:15,maxWidth:580,margin:"0 auto 24px",lineHeight:1.9}}>
            A formal petition to the Australian House of Representatives. Under parliamentary rules, 10,000 verified signatures <strong style={{color:"#4caf50"}}>legally forces a mandatory Legislative Review Committee investigation</strong> — into bail surety reform, legal defence insurance, and digital consent evidence admissibility.
          </p>
          <div style={{display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap",marginBottom:24}}>
            <Btn onClick={()=>onNav('petition')} color="#4caf50" textColor="#fff" size="lg">✍️ Sign the Petition Now</Btn>
            <a href="/ConsentVault_Parliamentary_Petition.pdf" download style={{background:"#1a2a5e",color:"#c8d8ff",border:"none",borderRadius:10,cursor:"pointer",padding:"16px 32px",fontSize:16,fontWeight:800,fontFamily:"inherit",textDecoration:"none",display:"inline-block"}}>
              📄 Download Paper Form
            </a>
          </div>
          <div style={{display:"flex",gap:24,justifyContent:"center",flexWrap:"wrap",fontSize:12,color:"#445"}}>
            {["✅ Facial Verification Required","✅ Driver's Licence or Passport","✅ Drawn Digital Signature","✅ Full Identity Verified"].map(t=><span key={t}>{t}</span>)}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <div id="pricing" style={{background:"#0a0f1e",borderTop:"1px solid #1a2a4a",borderBottom:"1px solid #1a2a4a"}}>
        <div style={{maxWidth:1100,margin:"0 auto",padding:"72px 24px"}}>
          <div style={{textAlign:"center",marginBottom:40}}>
            <div style={{fontSize:11,color:GOLD,letterSpacing:4,textTransform:"uppercase",marginBottom:10}}>Pricing</div>
            <h2 style={{fontSize:32,fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:"0 0 20px"}}>Choose Your Protection Level</h2>
            <div style={{display:"inline-flex",background:"#07080f",border:"1px solid #1a2a4a",borderRadius:30,padding:4,gap:4}}>
              {[["Monthly","monthly"],["Annual — Save up to $47","annual"]].map(([l,v])=>(
                <button key={v} onClick={()=>setBilling(v==="annual")}
                  style={{background:(v==="annual")===billing?GOLD:"transparent",color:(v==="annual")===billing?"#07080f":"#556",border:"none",borderRadius:24,padding:"8px 20px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit",transition:"all 0.2s"}}>{l}</button>
              ))}
            </div>
          </div>
          <div style={{display:"flex",gap:16,flexWrap:"wrap",marginBottom:24}}>
            {plans.map((p,i)=>(
              <div key={i} style={{flex:1,minWidth:220,background:p.highlight?"linear-gradient(160deg,#0d1e4a,#0a1628)":"#07080f",border:p.highlight?"2px solid #c9a84c":"1px solid #1a2a4a",borderRadius:16,padding:24,position:"relative",boxShadow:p.highlight?"0 0 40px #c9a84c18":"none"}}>
                {p.highlight&&<div style={{position:"absolute",top:-14,left:"50%",transform:"translateX(-50%)",background:GOLD,color:"#07080f",fontSize:10,fontWeight:900,padding:"4px 16px",borderRadius:20,letterSpacing:2,whiteSpace:"nowrap"}}>⭐ MOST POPULAR</div>}
                <div style={{fontSize:10,color:"#4a7aee",letterSpacing:3,textTransform:"uppercase",marginBottom:6}}>{p.tag}</div>
                <div style={{fontSize:19,fontWeight:800,color:"#c8d8ff",marginBottom:12}}>{p.name}</div>
                <div style={{marginBottom:16}}>
                  <span style={{fontSize:34,fontWeight:900,color:p.highlight?GOLD:"#8ab",fontFamily:"Georgia,serif"}}>{p.price}</span>
                  <span style={{fontSize:12,color:"#445"}}>/mo</span>
                  {p.annual&&<div style={{fontSize:12,color:"#4a6",marginTop:3}}>Billed annually at {p.annual}</div>}
                </div>
                <div style={{borderTop:"1px solid #1a2a4a",paddingTop:16,marginBottom:18}}>
                  {p.features.map((f,j)=>(
                    <div key={j} style={{display:"flex",gap:8,marginBottom:8,fontSize:12,color:"#778",alignItems:"flex-start"}}>
                      <span style={{color:"#4caf50",minWidth:14}}>✓</span><span>{f}</span>
                    </div>
                  ))}
                </div>
                <button onClick={()=>onNav('app')} style={{width:"100%",background:p.highlight?GOLD:"#1a2a5e",color:p.highlight?"#07080f":"#c8d8ff",border:"none",borderRadius:10,padding:"12px",fontSize:13,fontWeight:800,cursor:"pointer",fontFamily:"inherit"}}>{p.cta||`Get ${p.name}`}</button>
              </div>
            ))}
          </div>
          <div style={{background:"#100808",border:"1px solid #4a1a1a",borderRadius:12,padding:"18px 24px",textAlign:"center",fontSize:13,color:"#665"}}>
            🗄️ Records archived (not deleted) if subscription lapses. Archive retrieval fee: <strong style={{color:"#ff6b6b"}}>$2,200</strong> — covers forensic extraction, chain-of-custody, notarised court-ready re-issuance.
          </div>
        </div>
      </div>

      {/* COMING SOON INSURANCE */}
      <section style={{maxWidth:1100,margin:"0 auto",padding:"72px 24px"}}>
        <div style={{background:"linear-gradient(135deg,#0d0808,#0a0a1e)",border:"2px dashed #c9a84c44",borderRadius:20,padding:"48px 40px",position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",top:24,right:-32,background:GOLD,color:"#07080f",fontSize:11,fontWeight:900,padding:"6px 48px",transform:"rotate(45deg)",letterSpacing:3}}>COMING SOON</div>
          <div style={{fontSize:11,color:GOLD,letterSpacing:4,textTransform:"uppercase",marginBottom:12}}>🔜 Pending Parliamentary Reform</div>
          <h3 style={{fontSize:28,fontWeight:900,color:"#fff",fontFamily:"Georgia,serif",margin:"0 0 16px"}}>ConsentVault <span style={{color:GOLD}}>Legal Shield Insurance</span></h3>
          <p style={{color:"#778",fontSize:14,lineHeight:1.9,maxWidth:600,marginBottom:28}}>We are petitioning Parliament to create a new insurance category covering men accused of sexual offences. Sign the petition to make it happen.</p>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))",gap:14}}>
            {[["⚖️","Legal Defence Cover","Up to $100,000 towards criminal defence legal fees"],
              ["🏛️","Bail Surety Fund","Emergency funds to cover bail surety from $1K to $500K — ending remand injustice"],
              ["👨‍👧","Children's Support","Monthly payments to your children while you are incarcerated"],
              ["📞","24/7 Legal Hotline","Instant criminal defence solicitor connection the moment you're arrested"],
            ].map(([icon,title,desc])=>(
              <div key={title} style={{background:"#0a0a18",border:"1px solid #1a1a3a",borderRadius:10,padding:"14px 16px",display:"flex",gap:14}}>
                <span style={{fontSize:22,minWidth:32}}>{icon}</span>
                <div>
                  <div style={{fontWeight:700,color:"#c8d8ff",fontSize:13,marginBottom:3}}>{title}</div>
                  <div style={{fontSize:12,color:"#445",lineHeight:1.6}}>{desc}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{marginTop:24}}>
            <Btn onClick={()=>onNav('petition')} color="#4caf50" textColor="#fff" size="lg">✍️ Sign Petition to Make This Happen</Btn>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <div style={{background:"#0a0f1e",borderTop:"1px solid #1a2a4a",borderBottom:"1px solid #1a2a4a"}}>
        <div style={{maxWidth:800,margin:"0 auto",padding:"72px 24px"}}>
          <div style={{textAlign:"center",marginBottom:48}}>
            <div style={{fontSize:11,color:GOLD,letterSpacing:4,textTransform:"uppercase",marginBottom:10}}>FAQs</div>
            <h2 style={{fontSize:30,fontWeight:900,fontFamily:"Georgia,serif",color:"#fff"}}>Common Questions</h2>
          </div>
          {faqs.map(([q,a],i)=>(
            <div key={i} style={{border:"1px solid #1a2a4a",borderRadius:12,marginBottom:12,overflow:"hidden"}}>
              <button onClick={()=>setFaqOpen(faqOpen===i?null:i)} style={{width:"100%",background:faqOpen===i?"#0d1628":"#0a0f1e",border:"none",padding:"18px 24px",display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer",fontFamily:"inherit"}}>
                <span style={{fontSize:14,fontWeight:700,color:"#c8d8ff",textAlign:"left"}}>{q}</span>
                <span style={{color:GOLD,fontSize:18,minWidth:24}}>{faqOpen===i?"−":"+"}</span>
              </button>
              {faqOpen===i&&<div style={{padding:"16px 24px 20px",fontSize:13,color:"#778",lineHeight:1.8,background:"#0d1628",borderTop:"1px solid #1a2a4a"}}>{a}</div>}
            </div>
          ))}
        </div>
      </div>

      {/* FINAL CTA */}
      <section style={{maxWidth:1100,margin:"0 auto",padding:"80px 24px",textAlign:"center"}}>
        <h2 style={{fontSize:"clamp(26px,4vw,42px)",fontWeight:900,fontFamily:"Georgia,serif",color:"#fff",margin:"0 0 16px"}}>
          Three Minutes of Preparation.<br/><span style={{color:GOLD}}>A Lifetime of Protection.</span>
        </h2>
        <p style={{color:"#667",fontSize:15,maxWidth:500,margin:"0 auto 36px",lineHeight:1.9}}>Start with the consent vault. Add your surety contacts. Record your SOS message. When you need it — everything fires automatically.</p>
        <div style={{display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap",marginBottom:16}}>
          <Btn onClick={()=>onNav('app')} color={GOLD} textColor="#07080f" size="lg">🛡️ Start Free 7-Day Trial</Btn>
          <Btn onClick={()=>onNav('petition')} color="transparent" textColor="#c8d8ff" size="lg">✍️ Sign the Petition</Btn>
        </div>
        <div style={{fontSize:12,color:"#223"}}>No credit card required • Cancel anytime • 7-day money back guarantee</div>
      </section>

      {/* FOOTER */}
      <footer style={{background:"#030408",borderTop:"1px solid #0d1628",padding:"48px 24px 28px"}}>
        <div style={{maxWidth:1100,margin:"0 auto"}}>
          <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:40,marginBottom:36}}>
            <div style={{maxWidth:280}}>
              <VaultLogo size={34}/>
              <p style={{fontSize:12,color:"#223",lineHeight:1.8,marginTop:14}}>Australia's first legally-structured mutual consent vault with automated arrest detection, court monitoring, and emergency surety activation.</p>
              <div style={{fontSize:11,color:"#1a2a4a",marginTop:8}}>ABN: 52 347 989 391 • ConsentVault Pty Ltd</div>
            </div>
            {[{head:"Platform",links:["Consent App","SOS Alert","Surety Network","Court Monitoring","Archive Policy","Pricing"]},
              {head:"Reform",links:["Sign Petition","Insurance Waitlist","Parliamentary Process","Opposition Brief","Men's Rights","Media Kit"]},
              {head:"Legal",links:["Terms of Service","Privacy Policy","Data Retention","Disclaimer","Cookie Policy"]},
            ].map(col=>(
              <div key={col.head}>
                <div style={{fontSize:10,color:"#334",letterSpacing:3,textTransform:"uppercase",marginBottom:14}}>{col.head}</div>
                {col.links.map(l=><div key={l} style={{fontSize:12,color:"#223",marginBottom:9,cursor:"pointer"}} onMouseEnter={e=>e.target.style.color=GOLD} onMouseLeave={e=>e.target.style.color="#223"}>{l}</div>)}
              </div>
            ))}
          </div>
          <div style={{background:"#0a0f1e",border:"1px solid #1a2a4a",borderRadius:10,padding:"14px 20px",marginBottom:28,display:"flex",gap:24,flexWrap:"wrap",alignItems:"center"}}>
            <div style={{fontSize:10,color:"#334",letterSpacing:2,textTransform:"uppercase"}}>🆘 Men's Support:</div>
            {[["MensLine Australia","1300 78 99 78"],["Lifeline","13 11 14"],["Beyond Blue","1300 22 4636"]].map(([n,p])=>(
              <div key={n} style={{fontSize:12}}><span style={{color:"#445"}}>{n}: </span><span style={{color:GOLD,fontWeight:700}}>{p}</span></div>
            ))}
          </div>
          <div style={{borderTop:"1px solid #0d1628",paddingTop:20,display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:10,fontSize:11,color:"#1a2a4a"}}>
            <div>© 2026 ConsentVault Pty Ltd • consentvault.com.au • All rights reserved</div>
            <div>⚠️ ConsentVault does not provide legal advice. Consult a qualified Australian solicitor.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}

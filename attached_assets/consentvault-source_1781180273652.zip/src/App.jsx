import { useState, useEffect } from 'react'
import Landing from './pages/Landing.jsx'
import PetitionPage from './pages/PetitionPage.jsx'
import ConsentApp from './pages/ConsentApp.jsx'

function getRoute() {
  const hash = window.location.hash.replace('#', '').replace('/', '') || ''
  if (hash === 'petition') return 'petition'
  if (hash === 'app' || hash === 'consent') return 'app'
  return 'home'
}

export default function App() {
  const [route, setRoute] = useState(getRoute())

  useEffect(() => {
    const onHash = () => setRoute(getRoute())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const nav = (page) => {
    window.location.hash = page === 'home' ? '' : page
    window.scrollTo(0, 0)
  }

  if (route === 'petition') return <PetitionPage onNav={nav} />
  if (route === 'app') return <ConsentApp onNav={nav} />
  return <Landing onNav={nav} />
}
